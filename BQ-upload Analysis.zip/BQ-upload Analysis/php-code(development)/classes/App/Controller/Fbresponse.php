<?php
namespace App\Controller;
session_start();
class Fbresponse extends \App\Page {

	public function before(){
	}

	public function action_index() {
		
		$this->view = $this->pixie->view('fbresponse');
		/*
		if($_SESSION['postid'])
		{
			$this->view->postid = $_SESSION['postid'];
		}
		
		if ($this->request->method == 'POST') {
			//$this->view = $this->pixie->view('fbresponse');
			$this->view->postid = $this->request->post('postid');
			$this->view->access_token = $this->request->post('access_token');
		
		}
		*/
		$_SESSION['access_token'] = 'CAAIwxXeCBc4BAIJW9IvTmprD5i2RNUt6riBNEmhD9ECBjuDDc8jahfKJeU3SotRbUJ1xekikWAwc4RAmwvI1ZBN1PYWZCgNTJ17EMnyoQoZB4Fn73ZAehisyknw1WtyDDpTLxFvlT1hgindnnSPDHoFOZBxHCHdrypgScAZCaXXHUwZBsZCeWG4KVGDQhZAIchG0x0tUSrzintZCVqYm5Y3Xk6NrKPZCXHFnXZBZAfH8aDIwhKfs44TkZAGyvP';
		$this->response->body = $this->view->render();
	}
	public function after(){
		//$this->response->body = $this->view->render();
	}

}
