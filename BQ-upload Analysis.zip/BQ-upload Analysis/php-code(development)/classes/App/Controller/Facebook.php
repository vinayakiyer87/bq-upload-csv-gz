<?php

namespace App\Controller;
class Facebook extends \AuthN\Controller\Facebook{
}
