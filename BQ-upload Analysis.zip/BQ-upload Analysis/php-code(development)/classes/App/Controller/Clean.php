<?php
namespace App\Controller;
require_once 'google/appengine/api/cloud_storage/CloudStorageTools.php';
use google\appengine\api\cloud_storage\CloudStorageTools;

class Clean extends \App\WebServicePage {
	
	public function before(){
	}

	/* Database connection */
	public function makeConnection($pixie,$driver)
	{
		$connection = '';
		if(!empty($driver) && is_object($pixie))
		{
			switch($driver)
			{
				case 'PDO':
					$connection = $pixie->db->get('PDO');
					break;
				case 'datastore':
					$connection = $pixie->orm->get('Incident');
					break;
					
			}
		}
		return $connection?$connection:null;
	}
	/* End Database connection */
	
	/* Upload Before and After pics */
	public function action_upload()
	{
		$headers = array();
		
		if(sizeof($_SERVER)>0)
		{
			foreach($_SERVER as $key => $value) {
			if (substr($key, 0, 5) <> 'HTTP_') {
				continue;
			}
			$header = str_replace(' ', '-', str_replace('_', ' ', strtolower(substr($key, 5))));
			$headers[$header] = $value;
			}
		}
		
		if(isset($headers['action']))
		{
			$response =array();
			$con = $this->makeConnection($this->pixie,'PDO');
			$arr = $arrprofile = array();
					
			$campaign_title='';		
			if(isset($headers['fb-id']) && !empty($headers['fb-id']))
				$arr['fb_id'] = $arrprofile['fb_id'] = $headers['fb-id'];
		
			if(isset($headers['campaign-title']) && !empty($headers['campaign-title']))
				$campaign_title =  $headers['campaign-title'];
					
			if(strtolower(trim($headers['action']))=='create')
			{
				if(isset($headers['lat']) && !empty($headers['lat']))
					$arr['lat'] = $headers['lat'];	
			
				if(isset($headers['lng']) && !empty($headers['lng']))
					$arr['lng'] = $headers['lng'];	
				
				$arr['campaign_title'] = $campaign_title;
				
				$num = 0;
				$num = $con->query('count')->table('user_profile')->where('fb_id',$arr['fb_id'])->execute();
				$newprofile = false;
				
				if($num==0)
				{
					/*if(isset($data['profilepics']) && !empty($data['profilepics']) && isset($data['fb_id']) && !empty($data['fb_id']))
					{
						$profilepics = $data['profilepics'];
						
						$profilepics = base64_decode($profilepics);
						
						$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
						$ctx = stream_context_create($options);
						file_put_contents('gs://clean-india/profilepics/'.$data["fb_id"].'.jpeg', $profilepics, 0, $ctx);
						
						$arrprofile['profile_pic'] = 'http://storage.googleapis.com/clean-india/profilepics/'.$data["fb_id"].'.jpeg';
					}
					
					if(isset($data['email']) && !empty($data['email']))
					{
						$arrprofile['email']= $data['email'];
					}*/
					$ws = $con->query('insert')->table('user_profile')->data($arrprofile)->execute();
				}
				
				$arr['status'] = "0";
				$date = date_create();
				$date = date_format($date,'Y-m-d H:i:s');	
				$arr['started_on'] = $date;
				
				$ws = $con->query('insert')->table('campaign')->data($arr)->execute();
				$temp['id'] = $con->insert_id();
				
				if(isset($_FILES['uploadedfile']['tmp_name']))
				{
					$gs_name = $_FILES['uploadedfile']['tmp_name'];
				
					$options = array('gs'=>array('acl'=>'public-read','Content-Type' => 'image/jpeg'));
					$ctx = stream_context_create($options);
					$name = $temp['id'].'_'.rand(100,999).time().'.jpg';
					
					copy($gs_name,'gs://clean-india/beforepics/'.$name,$ctx);
					$arr['before_pics'] = 'http://storage.googleapis.com/clean-india/beforepics/'.$name;
					
				}
				
				$beforearr['before_pics']=$arr['before_pics'];
				$ws = $con->query('update')->table('campaign')->data($beforearr)->where('id',$temp['id'])->execute();
				
				//$response['data'] = $temp;
				$response['status']  = "success";	
				$response['campaignid']  = $temp['id'];	
			}
			
			if(strtolower(trim($headers['action']))=='update')
			{
				if(isset($arr['fb_id']) && $arr['fb_id'] && isset($headers['access-token']) && $headers['access-token'])
				{
					//$_SESSION['fb_id']=$data['fb_id'];
					$fb_id = $arr['fb_id'];
					$access_token = $headers['access-token'];
					
					$arr_profile['access_token']=$headers['access-token'];
					$ws = $con->query('update')->table('user_profile')->data($arr_profile)->where('fb_id',$arr['fb_id'])->execute();
				}
				
				
				$ws = $con->query('select')->fields('*')->table('campaign')->where('id',$campaign_title)->execute();
				$id = $before_pics = $after_pics = $arr['final_pics'] = '';
				
				if($ws)
				{
					foreach($ws as $val)
					{
						$id = $val->id;
						$before_pics = $val->before_pics;
						
						//$after_pics = $val->after_pics;
					}
				}	
				
				if(!empty($id))				
				{
					$date = date_create();
					$date = date_format($date,'Y-m-d H:i:s');	
					$arr['completed_on'] = $date;
					
					/*
					if(!empty($data['post_id']))
					{
						$arr['post_id'] = $data['post_id'];
					}*/
					
					
					if(isset($_FILES['uploadedfile']['tmp_name']))
					{
						$gs_name = $_FILES['uploadedfile']['tmp_name'];
					
						$options = array('gs'=>array('acl'=>'public-read','Content-Type' => 'image/jpeg'));
						$ctx = stream_context_create($options);
						$name = $id.'_'.rand(100,999).time().'.jpg';
						//copy($_FILES['uploadedfile']['tmp_name'],'gs://clean-india/afterpics/test_new.png',$ctx);
						//move_uploaded_file($gs_name, 'gs://clean-india/afterpics/'.$name); 
						copy($gs_name,'gs://clean-india/afterpics/'.$name,$ctx);
						$arr['after_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$name;
						
					}
					
					///////////////// IMAGE MERGE CODE  //////////////////
					//$path = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
					//echo $path.'\\assets\\views\\images\\1.jpg';die;
					
					if($before_pics && $arr['after_pics'])
					{
						//$img1_path = $path.'\\assets\\views\\images\\1.jpg';
						//$img2_path = $path.'\\assets\\views\\images\\2.jpg';
						
						$img1_path = $before_pics;
						$img2_path = $arr['after_pics'];
						
						list($img1_width, $img1_height) = getimagesize($img1_path);
						list($img2_width, $img2_height) = getimagesize($img2_path);
						
						$merged_width  = $img1_width + $img2_width;
						//get highest
						$merged_height = $img1_height > $img2_height ? $img1_height : $img2_height;

						$merged_image = @imagecreatetruecolor($merged_width, $merged_height);
						
						@imagealphablending($merged_image, false);
						@imagesavealpha($merged_image, true);
						
						
						$file_dimensions = getimagesize($img1_path);
						$file_type = strtolower($file_dimensions['mime']);
							
						if ($file_type=='image/jpeg'||$file_type=='image/pjpeg')
							{
							$img1 = @imagecreatefromjpeg($img1_path);
						
							@imagecolorallocate($img1, 15, 142, 210);
							@imagesetthickness($img1, 5);
							
							$white = @imagecolorallocate($img1, 255, 255, 255);

							  $x = 0;
							  $y = 0;
							  $w = @imagesx($img1) - 1;
							  $z = @imagesy($img1) - 1;

							  @imageline($img1, $x, $y, $x, $y+$z, $white);
							  @imageline($img1, $x, $y, $x+$w, $y, $white);
							  @imageline($img1, $x+$w, $y, $x+$w, $y+$z, $white);
							  @imageline($img1, $x, $y+$z, $x+$w ,$y+$z, $white);

							  $font_path = dirname(__FILE__).'/font.TTF';
							  // Set Text to Be Printed On Image
							  $text = "Before";

							  // Print Text On Image
							  @imagettftext($img1, 25, 0, 10, 30, $white, $font_path, $text);
							
							
							$file_dimensions = getimagesize($img2_path);
							$file_type = strtolower($file_dimensions['mime']);
								
							if ($file_type=='image/jpeg'||$file_type=='image/pjpeg')
							{	
								$img2 = @imagecreatefromjpeg($img2_path);
								
								@imagecolorallocate($img2, 15, 142, 210);
								@imagesetthickness($img2, 3);
								$white = @imagecolorallocate($img2, 255, 255, 255);

								  $x = 0;
								  $y = 0;
								  $w = @imagesx($img2) - 1;
								  $z = @imagesy($img2) - 1;

								  @imageline($img2, $x, $y, $x, $y+$z, $white);
								  @imageline($img2, $x, $y, $x+$w, $y, $white);
								  @imageline($img2, $x+$w, $y, $x+$w, $y+$z, $white);
								  @imageline($img2, $x, $y+$z, $x+$w ,$y+$z, $white);

								  // Set Text to Be Printed On Image
								  $text = "After";

								  // Print Text On Image
								  @imagettftext($img2, 25, 0, 10, 30, $white, $font_path, $text);
								
								
								@imagecopy($merged_image, $img1, 0, 0, 0, 0, $img1_width, $img1_height);
								//place at right side of $img1
								@imagecopy($merged_image, $img2, $img1_width, 0, 0, 0, $img2_width, $img2_height);
								
								//save file or output to broswer
								$SAVE_AS_FILE = TRUE;
								if( $SAVE_AS_FILE ){
									$save_path = 'gs://clean-india/afterpics/temp.jpg';
									$r=imagejpeg($merged_image,$save_path);
									
									$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
									$ctx = stream_context_create($options);
									$name = 'final_'.rand(100,999).time().'.jpg';
									//move_uploaded_file($save_path, 'gs://clean-india/afterpics/'.$name); 
									copy($save_path,'gs://clean-india/afterpics/'.$name,$ctx);
									$arr['final_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$name;
								}else{
									//header('Content-Type: image/png');
									$finalImg = @imagejpeg($merged_image);
									
									$options = [ "gs" => [ "Content-Type" => "image/png" ,"acl"=>"public-read"]];
									$ctx = stream_context_create($options);
									$name = 'final_'.rand(100,999).time().'.png';
									file_put_contents('gs://clean-india/afterpics/'.$name, $finalImg, 0, $ctx);
									
									$arr['final_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$name;
								}
							
					}
					else
						{
						$response['status'] = 'success';
							$response['message'] = 'AFTER_IMAGE_IS_NOT_A_JPG_FILE';
							print json_encode($response);
							die; 
						}
					}	
					else	
					{
					$response['status'] = 'success';
							$response['message'] = 'BEFORE_IMAGE_IS_NOT_A_JPG_FILE';
							print json_encode($response);
							die; 
					
					}
					}
					$arr['status'] = '1';
					
					$ws = $con->query('update')->table('campaign')->data($arr)->where('id',$id)->execute();
					
					$response['post_id']='';
					
					$postmsg = '';
					
					if(isset($headers['message']))
						$postmsg = $headers['message'];
					
					/* POSTING on user's wall */
					$params = array(
						"url" => $arr['final_pics'],
						"message" => $postmsg,
						"access_token" => $access_token
					);
					$data1 = http_build_query($params);
					$context = array(
					  'http' => array(
						'method' => "POST",
						'header'  => "Content-Type: application/x-www-form-urlencoded",
						'content'	=> $data1
					  )
					);
					$context = stream_context_create($context);
					$response1 = file_get_contents("https://graph.facebook.com/v2.2/me/photos", false, $context);
					/* End posting on user's wall */
					
					
					/* Posting on page wall */
					$params = array(
						"url" => $arr['final_pics'],
						"message" => $postmsg,
						"access_token" => $access_token
					);
					$data2 = http_build_query($params);
					$context = array(
					  'http' => array(
						'method' => "POST",
						'header'  => "Content-Type:  application/x-www-form-urlencoded",
						'content'	=> $data2
					  )
					);
					$context = stream_context_create($context);
					$response1 = file_get_contents("https://graph.facebook.com/v2.2/1513506835555076/photos", false, $context);
					/* End Posting on page wall */
					
					$arr_postid = array();
					$parse = json_decode($response1);
					
					if(isset($parse->id) && !empty($parse->id))
					{
						$arr_postid['post_id'] = $parse->id;
						$ws = $con->query('update')->table('campaign')->data($arr_postid)->where('id',$id)->execute();
						$response['post_id']  = $arr_postid['post_id'];	
					}	
					
				}
				$response['status']  = "success";	
			}
			
			print json_encode($response);
			die;
		}		
	}
	/* End Upload Before and After pics */
	
	/* Generating upload URL */
	public function action_index() {
	
	$options = [ 'gs_bucket_name' => 'clean-india' ];
	$upload_url = CloudStorageTools::createUploadUrl('/Clean/upload', $options);
	$response = array();
	if($upload_url)
		$response['data'] = $upload_url;
	else
		$this->redirect('/index'); 
		
	echo json_encode($response);

	}
	/* End Generating upload URL */
	
	/* Tagging FB friends */
	public function action_tags(){
		$response =array();
		$response['status'] = 'success';
		
		$tag_friends = '';
		
		if(isset($_POST['tags']) && !empty($_POST['tags']))
		{
			$tag_friends_arr =  explode(",",ltrim($_POST['tags'],","));
			if(sizeof($tag_friends_arr)>0)
			{
				$tag_friends = '[';
				foreach($tag_friends_arr as $val)
				{
					$tag_friends.= "{'tag_uid':'".$val."'},";
					/*$x = rand(3,200);
					$y = rand(5,200);
					$tag_friends.= "{'tag_uid':'".$val."','x':".$x.",'y':".$y."},";*/
				}
				$tag_friends = rtrim($tag_friends,",")."]";
			}
		}
		else{
			
			$response['message'] = 'FB_IDs_NOT_FOUND';
			print json_encode($response);
			die;
		}	
		
		if(isset($_POST['post_id']) && !empty($_POST['post_id']))
			$post_id =  $_POST['post_id'];
		else
		{
			$response['message'] = 'POST_ID_NOT_SET';
			print json_encode($response);
			die;
		}	
				
		if(isset($_POST['access_token']) && !empty($_POST['access_token']))
			$access_token =  $_POST['access_token'];
		else
		{
			$response['message'] = 'ACCESS_TOKEN_NOT_SET';
			print json_encode($response);
			die;
		}
		
		if($tag_friends && $post_id && $access_token)
		{
			$url = 'https://graph.facebook.com/v2.2/'.$post_id.'/tags';
			
			/*$params = array(
				"tags" => "[{'tag_uid': '".$fb_id.",838263266195161'}]",
				"access_token" => $access_token
			);*/
			
			$params = array(
				"tags" => $tag_friends,
				"access_token" => $access_token
			);
			$data2 = http_build_query($params);
			$context = array(
			  'http' => array(
				'method' => "POST",
				'header'  => "Content-Type:application/x-www-form-urlencoded",
				'content'	=> $data2
			  )
			);
			$context = stream_context_create($context);
			$response1 = file_get_contents($url, false, $context);
			
			if(stristr($response1,'error'))
				$response['status'] = 'failure';
			else	
				$response['data'] = $response1;	
		}			
			print json_encode($response);
			die;
	}
	/* End Tagging FB friends */
}
