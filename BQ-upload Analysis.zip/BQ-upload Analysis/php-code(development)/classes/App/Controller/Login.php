<?php

namespace App\Controller;

class Login extends \App\WebServicePage {
	protected $auth;
	protected $user;
	public function before(){
		/*$this->auth = new \AuthN\AuthN;
		$this->user = $this->auth->user();
		//print_r($this->user);die;
		if(isset($this->user))
		{
			switch($this->user->getRole())
			{
				case 'admin' : $this->redirect('/Admin'); break;
				case 'customer' : $this->redirect('/Portal'); break;
				case 'general' : $this->redirect('/Portal'); break;
			}
		}*/
	}
	public function action_index() {
	require_once '../vendor/google/apiclient/src/Google/Client.php';
	require_once '../vendor/google/apiclient/src/Google/Service/Bigquery.php';
	//eval('echo "<script>top.location.href=\'http://clouddeals.mediaagility.com/Clean-India-App-Download-Now.html\';</script>";');
		//$this->redirect('https://www.facebook.com/photo.php?fbid=782931591764881&set=o.1513506835555076&type=1');
		//die;
	//	$this->view = $this->pixie->view('signin');
	$client = new \Google_Client();
	$client->setRedirectUri('http://axis-bank.appspot.com/index.php');
//$service_token_file_location = 'keys/bigquery_current_service_token.json';
// Your project id
	$project_id = 'axis-bank';
	$client->setApplicationName("axis-bank");

	$key = file_get_contents('../keys/axis-bank-ee77ece0c270.p12');

	$client->setAssertionCredentials(new \Google_Auth_AssertionCredentials(
                "373387281435-bgj27olmfrddnsgqeoq377moi1ns23kt@developer.gserviceaccount.com",
                array('https://www.googleapis.com/auth/bigquery'),
                $key));
	//print_r($client);
	$bq = new \Google_Service_Bigquery($client);
	
	$queryPos = new \Google_Service_Bigquery_QueryRequest();
	
	
	 $fields = array(
        array('name' => 'avg_time', 'type' => 'floar', 'mode' => 'nullable'),
        array('name' => 'emp_id', 'type' => 'integer', 'mode' => 'nullable'),
        array('name' => 'emp_name', 'type' => 'string', 'mode' => 'nullable'),
        array('name' => 'month', 'type' => 'integer', 'mode' => 'nullable')
    );
	
	$qry = 'SELECT * FROM [mydataset.mytable]';

	/*$qry = "SELECT page_title,
	IF (page_title CONTAINS 'search', 
      INTEGER(total), 0) AS search,
	IF (page_title CONTAINS 'Earth' OR 
      page_title CONTAINS 'Maps', INTEGER(total), 0) AS geo,
	FROM
	(SELECT
    TOP (title, 5) as page_title,
    COUNT (*) as total
	FROM
     [publicdata:samples.wikipedia]
	WHERE
     REGEXP_MATCH (title, r'^Google.+') AND wp_namespace = 0
	);";
	*/
	$queryPos->setQuery($qry);
  
  // Do something with the BigQuery API $response data
	//$result = exec_query($queryPos,$project_id);
	
	
	$job = new \Google_Service_Bigquery_Job();
	$config = new \Google_Service_Bigquery_JobConfiguration();
	$config->setDryRun(false);
	$queryConfig = new \Google_Service_Bigquery_JobConfigurationQuery();
	$config->setQuery($queryConfig);

	$job->setConfiguration($config);

	$destinationTable = new \Google_Service_Bigquery_TableReference();
	$destinationTable->setDatasetId("mydataset");
	$destinationTable->setProjectId("axis-bank");
	$destinationTable->setTableId('mytab1');

	$schema = new \Google_Service_Bigquery_TableSchema();
    $schema->setFields($fields);
    $table = new \Google_Service_Bigquery_Table();
    $table->setTableReference($destinationTable);
    $table->setSchema($schema);
	
	
	$queryConfig->setDestinationTable($destinationTable);


	
	try {
	    
	//    exit;
	//$job = new \Google_Service_Bigquery_Job($bq->jobs->insert("axis-bank", $job));
		$job = $bq->jobs->insert('axis-bank', $job);

		/*$status = new \Google_Service_Bigquery_JobStatus();
		$status = $job->getStatus();
	    
		if ($status->count() != 0) {
			$err_res = $status->getErrorResult();
			die($err_res->getMessage());
		}*/
	} catch (\Google_Service_Exception $e) {
	echo "catch";
		echo $e->getMessage();
		exit;
	}
	echo "here";
	print_r($job);
	$jr = $job->getJobReference();
	var_dump($jr);
	$jobId = $jr['jobId'];
	/*
	if ($status)
		$state = $status['state'];

	echo 'JOBID:' . $jobId . " ";
	echo 'STATUS:' . $state;
*/


	
	
	
	
	
	
	
	
	
	$res = $bq->jobs->query($project_id, $queryPos);

	//$res = $bq->jobs->getQueryResults("axis-bank", $_GET['jobId'], array('timeoutMs' => 1000));

	/*if (!$res->jobComplete) {
		echo "Job not yet complete";
		exit;
	}*/
	echo "<p>Total rows: " . $res->totalRows . "</p>\r\n";
	//see the results made it as an object ok
	//print_r($res);
	$rows = $res->getRows();
	$r = new \Google_Service_Bigquery_TableRow();
	$a = array();
	foreach ($rows as $r) {
		$r = $r->getF();
		$temp = array();
		foreach ($r as $v) {
			$temp[] = $v->v;
		}
		$a[] = $temp;
	}
	print_r($a);


	
	
	
	
	/*
	$jobs = $bq->jobs;
	$response = $jobs->query($project_id, $queryPos);
	$schema = $response->getSchema();
	$fields = $schema->getFields();
	$rows = $response->getRows();
	
	$count = $response->totalRows;
	if($count>0){
		$arrField = array();
		foreach ($fields as $field=>$name){
			$arrField[$field]=$name['name'];
		}
		$result = array();
		foreach ($rows as $row=>$val){
			foreach ($val['modelData']['f'] as $k=>$v){
				$result[$row][$arrField[$k]]=$v['v'];
			}
		}
		if(!empty($result)){
			print_r($result);die;
		}
	}
	*/
}
}