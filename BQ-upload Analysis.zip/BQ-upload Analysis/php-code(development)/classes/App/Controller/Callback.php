<?php
namespace App\Controller;

class Callback extends \App\WebServicePage {

	public function before(){
	//	$this->post = json_decode(file_get_contents("php://input"),true);
	/*	$this->auth = new \AuthN\AuthN;
		$this->user = $this->auth->user();
		if(isset($this->user))
		{
			switch($this->user->getRole())
			{
				case 'admin' : ; break;
				case 'customer' : $this->redirect('/Portal'); break;
				case 'general' : $this->redirect('/Portal'); break;
				
			}
		}
		else{
			$this->redirect('/Login');
		}*/
	}

	public function action_index() {
		print_r($_REQUEST);die;
		/*
		$id = $this->request->post('id');
		$lat = $this->request->post('lat');
		$lng = $this->request->post('lng');
		$radius = $this->request->post('rad');
		$key = $this->request->post('key');
		*/
		//$i=4;
		/*
		try{
			if($i>2)
			{
				throw new \Exception("Value must be 1 or below");
			}
		}
		catch (\Exception $e) {
			echo 'Message: ' .$e->getMessage();
		}
		*/		
		
		//$place = $this->pixie->orm->get('place');
		
		//$fairy = $this->pixie->orm->get('SQLPlace')->where('place_name','Quick Bite')->find_all();
		
		//print_r($fairy);
		
		//foreach ($fairy as $web)
        //{
			//print_r($web);
			//echo "\n";
		//}
		
		//$res=$this->vincentyGreatCircleDistance(18.406522, 73.505752, 18.406847, 73.505922);
		//$res=$this->vincentyGreatCircleDistance(18.407656,73.507452,18.399865,73.500536);
		//print_r($res);die;
		//40.344539480537
		//print $radius."===".$id."==usergeolocation===".$loc;
		
		//$res = $this->getplacedata('post',$lat,$lng,$radius,'food',$key);
		
		//$ws = $this->pixie->orm->get('place')->where('user_location', 'Inside')->find_all();
		
		//print_r($ws);die;
          //      foreach ($ws as $web)
            //      {
                  //  echo $web->user_location;
            //      }
				/*
				$date = new \DateTime('07/04/2014');
				$date->setTime(14, 55, 24);
				$date =  date_format($date, 'Y-m-d H:i:s');
				
				*/
	
		
		//$url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=hospitals+in+lavasa&key=AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
		//$url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=18.40249110,73.504929299999960&radius=2000&types=food&name=&key=AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
		
		$url = "https://maps.googleapis.com/maps/api/place/textsearch/json?pagetoken=CoQDeAEAAPunf1ovwSmCAHtStV9kFY5NeDYLnLHnc4C3BlyUq9PHHKRN59gmoVnIaGDMPiPSXleY_ITyGIkR8f8kb0EnatJAwS--EECRCu2WOzKsWOKX0CpKN7uig2xfQ8yJpPiGNPQZD7S3exA1XiW_t6MnhpCnCwfuKWNDGZBbm8KomYNK4rwppI2qPEvMc0lRzPhv92Wt1FWEt2sg0lyVCkfvusRJGBgosAff4QTHSYVJChjofrvOZk0DtvA0CmewyNCuO8zgXUdXnyykeFIYD_tz4jLVWrt4Q8Aa-nHZAhOFFbKu1Dw2q2IFLwYcunDdHCjn8i-8oH_D8lTjv5-CF7epKzLdJNcdeqjX3PBvk7ZGCxBxXie-b5rm8wI2a4icKq-N4PlsYqcTNxDNGOyu0XYPq7pT0KxCY0n6-7gHHGTRW6wsxiyxU3HZ_vF-_Je-bJIeEvarnfFLtMvX8NIHfvrUN5HbxD8SOaeoeabJ4OhsygqIgXEgh6poPiSLLtKU2R6SKRIQg08f1fYIIv_s9fY4KTezARoUVB2SkJSnH_3vw8GiQTVxTa74lW4&key=AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
		
		
		header('Content-type: application/json');
		$data = file_get_contents($url);
		$data = json_decode($data);
		
		print_r($data);
		/* Getting all keywords */ 
		$SQLkeywordData = $this->pixie->orm->get('SQLkeyword')->find_all();
		foreach ($SQLkeywordData as $key)
		{
			$keywordArr[$key->id] = $key->keyword_name;
        }										
		
		/* Inserting G Places data */
		$this->action_gpETL($keywordArr,$data);
		
		/*
		
		$SQLPlace = $this->pixie->orm->get('SQLPlace');
		$SQLPlace->place_name='test';
		$SQLPlace->save();
		
		
		$date = date_create();
		$date=date_format($date,'Y-m-d\TH:i:sP');		
				
		$place = $this->pixie->orm->get('place');
        $place->user_location = 'Inside';
        $place->place_type = 'food';
		$place->place_name = 'Cafe Coffee Day';
        $place->place_id = 'xcdrRtgFgF2KMj3';
        $place->lat = '18.8';
		$place->lng = '73.7';
        $place->formatted_address = 'test address';
        $place->formatted_phone_number = '23233232';
		$place->price_level = '3.3';
        $place->open_now = true;
        $place->icon = 'dfldsfs';
		$place->place_photo_reference = '';
        $place->gplus_url = '';
        $place->vicinity = '';
		$place->overall_rating = '4';
        $place->is_proximity = false;
        $place->is_featured = false;
		$place->is_inside360 = false;
        $place->inside360_id = '';
        $place->is_active = true;
		$place->is_synced = false;
        $place->added_on = $date;
        $place->updated_on = $date;
        $place->save();
			*/
		//print_r('Please use \'http://10.0.0.63:8080/Webservice/getplacedata/\' going onwards');
		
		//Chore
		//http://www.latlong.net/c/?lat=18.407656&long=73.507452
		
		//Mercury
		//18.399865
		//73.500536
		
		
		//$result = $res;
		//print_r($result);
		
		//	$this->view = $this->pixie->view('admin');
		/*	$this->view->user = $this->user->getName();
			$this->view->email = $this->user->getLoginId();
			$this->view->first_name = $this->user->getFirstName();
			$this->view->last_name = $this->user->getLastName();*/
			
	}
	
	/**
	 * Calculates the great-circle distance between two points, with
	 * the Vincenty formula.
	 * @param float $latitudeFrom Latitude of start point in [deg decimal]
	 * @param float $longitudeFrom Longitude of start point in [deg decimal]
	 * @param float $latitudeTo Latitude of target point in [deg decimal]
	 * @param float $longitudeTo Longitude of target point in [deg decimal]
	 * @param float $earthRadius Mean earth radius in [m]
	 * @return float Distance between points in [m] (same as earthRadius)
	 */
	public static function vincentyGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
	{
		// convert from degrees to radians
		$latFrom = deg2rad($latitudeFrom);
		$lonFrom = deg2rad($longitudeFrom);
		$latTo = deg2rad($latitudeTo);
		$lonTo = deg2rad($longitudeTo);

		$lonDelta = $lonTo - $lonFrom;
		$a = pow(cos($latTo) * sin($lonDelta), 2) +
		pow(cos($latFrom) * sin($latTo) - sin($latFrom) * cos($latTo) * cos($lonDelta), 2);
		$b = sin($latFrom) * sin($latTo) + cos($latFrom) * cos($latTo) * cos($lonDelta);

		$angle = atan2(sqrt($a), $b);
		return $angle * $earthRadius;
	}
	
	public function action_gpETL($keywordArr,$data) 
	{
		if(count($data)>0)
		{
			$nextPgToken = '';
			
			foreach($data as $key1=>$val1)
			{
				if($key1 == 'error_message' && $val1!='')
				{
					$err = $val1;
					break;
				}
				else{
					if(sizeof($val1)>0 && ($key1!='status' && $val1!='OK'))
					{
						if($key1=='next_page_token')
						{
							$nextPgToken = $val1;	
						}
						if($key1=='results')
						{
							foreach($val1 as $innerKey=>$innerVal)
							{
								if(count($innerVal)>0)
								{
									$placeContainer=array();
									
									foreach($innerVal as $newKey=>$newVal)
									{
										switch($newKey)
										{	
											case 'formatted_address':
												$placeContainer['formatted_address'] = $newVal;	
												break;
											case 'geometry':
												$placeContainer['lat'] = $newVal->location->lat;
												$placeContainer['lng'] = $newVal->location->lng;
												break;
											case 'icon':
												$placeContainer['icon'] = $newVal;
												break;
											case 'name':
												$placeContainer['place_name'] = $newVal;
												break;
											case 'opening_hours':
												$placeContainer['open_now'] = $newVal->open_now;
												break;
											case 'photos':
												$placeContainer['place_photo_reference'] = $newVal[0]->photo_reference;
												break;
											case 'place_id':
												$placeContainer['place_id'] = $newVal;
												$detailURL = "https://maps.googleapis.com/maps/api/place/details/json?placeid=".$newVal."&key=AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
												
												header('Content-type: application/json');
												$detData = file_get_contents($detailURL);
												$detData = json_decode($detData);
												
												//print_r($detData);
												if(count($detData)>0)
												{
													foreach($detData as $detkey1=>$detval1)
													{
														if($detkey1 == 'error_message' && $detval1!='')
														{
															$err = $detval1;
															break;
														}
														else
														{
															if(sizeof($detval1)>0 && ($detkey1!='status' && $detval1!='OK'))
															{
																if($detkey1=='result')
																{
																	foreach($detval1 as $detInnerKey=>$detInnerVal)
																	{		
																		if($detInnerKey == 'photos')
																		{
																			foreach($detInnerVal as $photoKey=>$photoVal)
																			{
																				$placeContainer['gallery_reference'] = $photoVal->photo_reference;
																			}
																		}
																		if($detInnerKey =='vicinity')
																			$placeContainer['vicinity'] = $detInnerVal;
																		
																		if($detInnerKey == 'reviews')
																		{
																			$arrReview = array();
																				
																			foreach($detInnerVal as $reviewKey=>$reviewVal)
																			{
																				$reviewData = $this->pixie->orm->get('SQLReview');
																				if(isset($reviewVal->author_name))
																					$reviewData->author_name = $reviewVal->author_name;
																				if(isset($reviewVal->author_url))
																					$reviewData->author_url = $reviewVal->author_url;
																				if(isset($reviewVal->language))
																					$reviewData->language = $reviewVal->language;
																				if(isset($reviewVal->rating))
																					$reviewData->rating = $reviewVal->rating;
																				if(isset($reviewVal->text))
																					$reviewData->review = $reviewVal->text;	
																				if(isset($reviewVal->time))
																					$reviewData->added_on = date("Y-m-d H:i:s", $reviewVal->time);
																				
																				$reviewData->place_id = $placeContainer['place_id'];
																			
																				$reviewData->save();		
																			}
																			
																		}
																		
																	}
																}
															}	
														}
													}
												}	
												break;
											case 'rating':
												$placeContainer['overall_rating'] = $newVal;
												break;
											case 'types':
												$placeContainer['types'] = $newVal;
												break;
												
										}	
									}
									
									//print_r($placeContainer);
									//echo "reviewsss=====";
									//print_r($arrReview);
									//die;
									/*
									$ws = $this->pixie->orm->get('SQLplace')->find_all();
									 
									foreach ($ws as $placeID)
									{
										$arrPlaceIDs[]= $placeID->place_id;
									}
									
									print_r($arrPlaceIDs);
									die;
									*/
									$placeContainer['added_on'] = date("Y-m-d H:i:s", time());
									/* Inserting Places in SQL */
									//print_r($placeContainer);die;
									
									if(count($placeContainer)>0)
									{
										$SQLplaceData = $this->pixie->orm->get('SQLplace');
										//$SQLplaceData->delete_all();
										foreach($placeContainer as $placeKey=>$placeVal)
										{
											if($placeKey == 'types')
											{
												foreach($placeVal as $k=>$v)
												{
													if(in_array($v,$keywordArr))
													{
														$SQLplaceKeywordData = $this->pixie->orm->get('SQLplaceKeyword');
												
														$SQLplaceKeywordData->place_id = $placeContainer['place_id'];	
														$SQLplaceKeywordData->keyword_id = array_search($v,$keywordArr);	
														
														$SQLplaceKeywordData->save();
													}
													
												}
											}	
											else
												$SQLplaceData->$placeKey = $placeVal;
										}
										$SQLplaceData->save();
									}
									
									/* Check for exisiting Place ID */
									/* Insert place data in MySql & DataStore */
									/* Insert place keyword map in MySql & DataStore */
									/* Insert Review data in MySql & DataStore */
								}
							}
							
							//die;
									/* Recursive Calling if next page exists */
									/*if($nextPgToken)
									{
										sleep(3000);
										$url = "https://maps.googleapis.com/maps/api/place/textsearch/json?pagetoken=".$nextPgToken."&key=AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
										header('Content-type: application/json');
										$data = file_get_contents($url);
										$data = json_decode($data);
										
										$this->action_gpETL($keywordArr,$data);
										die;
									}*/	
								
						}

						/* Write code to get next page data */	
					}
				}	
			}
		}
			
	}
	
	public function action_getplandata() {
	echo "http://localhost:9080/webservice/getplandata";
			
		$plan_id = $this->request->post('plan_id');
		$booked_date = $this->request->post('booked_date');
		$booked_for = $this->request->post('booked_for');
		$firstname = $this->request->post('firstname');
		$lastname = $this->request->post('lastname');
		$age = $this->request->post('age');  
		
		$planbooking = $this->pixie->orm->get('planbooking');
		
		//$planbooking = $this->pixie->orm->get('planbooking')->find_all();
		
		///foreach($planbooking as $key1=>$val1)
		//{
		//print_r($final);
		//}
		
		$planbookingparticipant = $this->pixie->orm->get('Planbookingparticipant');
		
		$planbooking->booked_for='121111212';
		$planbooking->user_id='1';
		$planbooking->save();                                        
		//$pixie->db->query('insert')->table('fairies')->data(array('name' => 'Trixie'))->execute();		
	}
	
	public function action_getplacedata() {
		//$url="https://www.googleapis.com/calendar/v3/calendars/2g92llggq39lofvdjtguln2o48@google.com/events/Mmc5MmxsZ2dxMzlsb2Z2ZGp0Z3VsbjJvNDggYXZhbmkubWVodGFAbWVkaWFh";
		//header('Content-type: multipart/form-data');
		//$data = file_get_contents($url);
		//$data = json_decode($data);
		//print_r($data);
		//2g92llggq39lofvdjtguln2o48@google.com
		//Mmc5MmxsZ2dxMzlsb2Z2ZGp0Z3VsbjJvNDggYXZhbmkubWVodGFAbWVkaWFh
		
		//$event = $service->events->get('primary', "eventId");

		//echo $event->getSummary();
		//die;
		$err = '';
		
		$id = $this->request->post('id');
		$lat = $this->request->post('lat');
		$lng = $this->request->post('lng');
		$type = $this->request->post('type');
		$rad = $this->request->post('rad');
		$key = $this->request->post('key');
			
		if($key=='' || !isset($key))
		{
			$err='No Authenticated Key found.';
		}	
		else{
			
			$url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=".$lat.",".$lng."&radius=".$rad."&types=".$type."&name=&key=".$key;
			
			header('Content-type: application/json');
			$data = file_get_contents($url);
			$data = json_decode($data);
			
			if(count($data)>0)
			{
				$destinationStr = '';
				foreach($data as $key1=>$val1)
				{
					if($key1 == 'error_message' && $val1!='')
					{
						$err = $val1;
						break;
					}
					else
					{
						if(sizeof($val1)>0 && $val1!='OK')
						{
							if($key1=='results' && count($val1)>0 ){
								foreach($val1 as $inner)
								{
									$destinationLat = $inner->geometry->location->lat;
									$destinationLng = $inner->geometry->location->lng;
									
									$destinationStr.= $destinationLat.",".$destinationLng."|";
									$placeidArr[] = $inner->place_id;
								}
							}
							if($key1=='status' && $val1=='ZERO_RESULTS')	
								$err = 'No data found';
						}
					}	
				}
			}
			
			/*############ Calculating distances #################*/
			
			if($destinationStr)
			{
				$destinationStr = rtrim($destinationStr,"|");
				
				$distURL="https://maps.googleapis.com/maps/api/distancematrix/json?origins=".$lat.",".$lng."&destinations=".$destinationStr."&mode=driving&language=en&key=".$key;
			
				$getdist = file_get_contents($distURL); 
				$data = json_decode($getdist);
				$cnt = 0;
				
				if(count($data)>0)
				{
					foreach($data->rows[0]->elements as $key=>$val)
					{
						$temp = array();
						$temp['place'] = $placeidArr[$cnt];
						$temp['dist'] = $val->distance->text;
						$str['nearby'][] = $temp;
						$cnt++;
					}
				}
			}	
			
			if($err == '')
			{
				$response['result'] = $str;
				$response['status'] = "OK";
			}
			else{
				$response['error_message'] = $err;
				$response['status'] = "Request Denied";
			}
			
			
			$final = json_encode($response);
			print_r($final);
			die;
			
		}	
	}

}
