<?php
namespace App\Controller;

class Webservice extends \App\WebServicePage
{
   public $request;
    
    protected $entity_mapping = array('campaigndata'=>'CampaignData');
    protected $operation_mapping = array('create' => 'create', 'update' => 'update', 'read' => 'read', 'delete' => 'delete','like'=>'like','comment'=>'comment');
    protected $response_mapping = array('success' => 'success', 'error' => 'error','count' =>'count','campaignid'=>'campaignid');
    protected $error_message = array('server' => 'Server error', 'client' => 'Invalid API Request');
    
    public function before()
    {
		$this->request = json_decode(file_get_contents("php://input"), true);
    }
    
    public function action_index()
    {
        $response            = array();
        $validation_response = $this->validate_signature();
        if ($validation_response['status'])
        {
			if ($this->map_entity($this->request['entity']))
            {
                $entity     = $this->map_entity($this->request['entity']);
                $data       = $this->request['data'];
				$className = "\App\WebserviceAPI\\".$entity;
                $entity_obj = new $className;
                $operation  = $this->operation_mapping[$this->request['action']];
                
                try
                {
                    $entity_response = $entity_obj->$operation($this->pixie,$data);
					
                    if (isset($entity_response['status']) && $entity_response['status'])
                    {
                        $response['status'] = $this->response_mapping['success'];
						
						if(isset($entity_response['message']))
							$response['message']   = $entity_response['message'];
						
						if(isset($entity_response['campaignid']))
							$response['campaignid']   = $entity_response['campaignid'];
						if(isset($entity_response['count']))
							$response['count']   = $entity_response['count'];
						if(isset($entity_response['totalCount']))
							$response['totalCount']   = $entity_response['totalCount'];
						if(isset($entity_response['ReportedCount']))
							$response['ReportedCount']   = $entity_response['ReportedCount'];
						if(isset($entity_response['ResolvedCount']))
							$response['ResolvedCount']   = $entity_response['ResolvedCount'];
						if(isset($entity_response['ProgressCount']))
							$response['ProgressCount']   = $entity_response['ProgressCount'];
						if(isset($entity_response['data']))
							$response['data']   = $entity_response['data'];
						else
							$response['data']   = new \stdClass;
							
                    }
                    else
                    {
                        $response['status'] = $this->response_mapping['error'];
                        $response['data']   = new \stdClass;
						
						if(isset($entity_response['message']))
							$response['message']   = $entity_response['message'];
						else
							$response['message']   = $this->error_message['client'];
                    }
				}
				catch (Exception $e)
				{
					$response            = $this->api_failure_response();
					$response['message'] = $this->error_message['server'];
				}
			}
            else
            {
                $response            = $this->api_failure_response();
                $response['message'] = $this->error_message['client'];
            }
        }
        else
        {
            $response            = $this->api_failure_response();
            $response['message'] = $validation_response['message'];
        }
		
		$json_response = json_encode($response);
		echo $json_response;
	}
    
    public function api_failure_response()
    {
        $response           = array();
        $response['status'] = $this->response_mapping['error'];
        $response['data']   = new \stdClass;
        return $response;
    }
    
    private function map_entity($request_entity)
    {
        if (isset($this->entity_mapping[$request_entity]))
            return $this->entity_mapping[$request_entity];
        else
            return false;
    }
    
    private function validate_signature()
    {
        $error = 0;
        if (isset($this->request['entity']) && $error == 0)
          {
          }
        else
          {
            $error = 1;
          }
        
        if (isset($this->request['action']) && $error == 0)
          {
          }
        else
          {
            $error = 1;
          }
        
        if (isset($this->request['data']) && $error == 0)
          {
          }
        else
          {
            $error = 1;
          }
         if(empty($this->request['action'])){
         	$error = 1;
         }
         else{
         	
         }
    	if(empty($this->request['entity'])){
         	$error = 1;
         }
         else{
         	
         }
        
        $response = array();
        if ($error == 0)
        {
            $response['status'] = true;
        }
        else
        {
            $response['status']  = false;
            $response['message'] = $this->error_message['client'];
        }
        return $response;
    }
}
