<?php

namespace App\Controller;
class Google extends \AuthN\Controller\Google {

}
