<?php
namespace App\Controller;

class Logout extends \App\Page {
	protected $auth;
	public function action_index() {
		$this->auth = new \AuthN\AuthN;
		$this->user = $this->auth->logout();
		$this->redirect('/Login');
	}
}
