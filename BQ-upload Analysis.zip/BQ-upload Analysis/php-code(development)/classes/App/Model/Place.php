<?php
namespace App\Model;

class Place extends \PHPixie\ORM\Model{

public $table = 'places';

}
