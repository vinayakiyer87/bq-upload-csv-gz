<?php
namespace App\Model;

class Review extends \PHPixie\ORM\Model{

//	public $table = 'place';

}

