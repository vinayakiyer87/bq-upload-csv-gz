<?php
namespace App\Model;

class Plan extends \PHPixie\ORM\Model{
	public $table = 'plan';
	public $connection = 'PDO';
}