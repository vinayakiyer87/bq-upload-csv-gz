<?php
namespace App;

/**
 * Base controller
 *
 * @property-read \App\Pixie $pixie Pixie dependency container
 */
class WebServicePage extends \PHPixie\Controller {

	//protected $view;
	protected $auth;
	public function before() {
		//$this->view = $this->pixie->view('main');
	}

	public function after() {
		//$this->response->body = $this->view->render();
	}
	/*
	protected function logged_in(){
		if($this->pixie->auth->user() == null){
           	 $this->login();
            	return false;
        }
        }

	protected function login(){
	$this->view = 'siginin';
        }

	protected function log_out(){
	$this->pixie->auth->logout();
	$this->logout();
	}*/

}
