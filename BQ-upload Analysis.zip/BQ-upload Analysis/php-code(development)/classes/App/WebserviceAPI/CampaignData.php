<?php
namespace App\WebserviceAPI;

class CampaignData {
	
	private $err,$countVal,$type,$limit,$offset,$radiusCompare,$order_by;
	
	public function read($pixie,$data)
	{
		$this->err = 'INVALID_PARAMETERS';
		$detailData = array();	
		$response['status'] = false;
		$this->countVal = 0;
		$this->type = $this->limit = $this->offset = $this->order_by = $this->radiusCompare = $rad = $cat = $fb_id = $lat = $lng = '';
		$ext = array();
		
		//if(!empty($data['user_id']))
		//	$this->confirmed = $data['user_id'];
		
		//if(!empty($data['lat']) && !empty($data['lng']) && is_numeric($data['lat']) && is_numeric($data['lng']))
		//{
			if(isset($data['radius']) && is_numeric($data['radius']))
			{
				$rad = $data['radius'];
			}
		
			if(isset($data['lat']) && !empty($data['lat']))
			{
				$lat = $data['lat'];
			}
			
			if(isset($data['lng']) && !empty($data['lng']))
			{
				$lng = $data['lng'];
			}
			// Creating DB connection
			$con = $this->makeConnection($pixie,'PDO');
			
			/* Updating access_token */
			
			if(isset($data['fb_id']) && $data['fb_id'])
			{
				$fb_id = $data['fb_id'];
			
				if(isset($data['access_token']) && $data['access_token'])
				{
					
					$arr_profile['access_token'] = $data['access_token'];
					$ws = $con->query('update')->table('user_profile')->data($arr_profile)->where('fb_id',$fb_id)->execute();
				}	
			
				/* End Updating access_token */
				
				// Getting NearBy Incidents' IDs 
				$getIds = $this->getCampaigns($pixie,$con,$lat,$lng,$rad,$cat,$fb_id);//$data['category'],$data['offset'],$data['limit']);
			
				$response['status'] = true;
				
				if(sizeof($getIds)<=0)
				{
					$response['message'] = 'NO_DATA_FOUND';
				}
				else
					$response['data'] = $getIds;
			}
			else
			{
				$response['message'] = 'INVALID_FACEBOOK_ID';
			}	
		//}		
		return $response;
	}
	
	public function makeConnection($pixie,$driver)
	{
		$connection = '';
		if(!empty($driver) && is_object($pixie))
		{
			switch($driver)
			{
				case 'PDO':
					$connection = $pixie->db->get('PDO');
					break;
				case 'datastore':
					$connection = $pixie->orm->get('Incident');
					break;
					
			}
		}
		return $connection?$connection:null;
	}
	
	public function getCampaigns($pixie,$con,$lat='',$lng='',$radius='',$category='',$fb_id='')//,$offset,$limit)
	{
		$arrIDs = array();
		$categoryStr = '';
		
		//if(!empty($lat) && !empty($lng))
		//{	
			if(!empty($radius) && is_numeric($radius))
				$this->radius      = ABS($radius);
			else
				$this->radius = 0;
			
			$orderBy      = " order by distance";
				
			if(isset($offset) && isset($limit) && is_numeric($offset) && is_numeric($offset))
				$this->limit      = " LIMIT ".ABS($offset).",".ABS($limit);
			
			if(!empty($this->radius) && $this->radius!=0)
				$this->radiusCompare = " HAVING distance<=".$this->radius;
			
			
			if(!empty($category))
				$categoryStr = " category ='".trim(strtolower($category))."' AND ";
				
				
				$ws = $con->query('select')->table('campaign')->where(array(array('lat','!=','0'),array('lng','!=','0')))->order_by('started_on','desc')->limit(1000)->execute();
				
				if(!empty($ws))
				{
					foreach($ws as $val)
					{
						$temp = array();
						$temp['liked'] = "0";
						 
						if(!empty($val->id) && !empty($fb_id))
						{
							$temp['id'] = $val->id; 
							
							$num=$con->query('count')->table('campaign_user_mapping')->where(array(array('fb_id','=',$fb_id),array('campaign_id','=',$val->id)))->execute();
							
							if($num>0)
								$temp['liked'] = "1";
						}	
						if(!empty($val->campaign_title))	
							$temp['campaign_title'] = $val->campaign_title;
						if(!empty($val->fb_id))
							$temp['fb_id'] = $val->fb_id; 
						if(!empty($val->lat))
							$temp['lat'] = $val->lat; 
						if(!empty($val->lng))	
							$temp['lng'] = $val->lng;
						if(isset($val->status))						
							$temp['status'] = $val->status; 
						$temp['before_pics'] = '';
						if(!empty($val->before_pics))
							$temp['before_pics'] = $val->before_pics;
						$temp['after_pics'] = '';
						if(!empty($val->after_pics))
							$temp['after_pics'] = $val->after_pics; 
						$temp['post_id'] = '';	
						if(!empty($val->post_id))
							$temp['post_id'] = $val->post_id;
						
						/*			
						if(!empty($val->completed_on))
							$temp['completed_on'] = $val->completed_on; */
						$arrIDs[] = $temp;
					}
				}
			//}
			
			/*#### [End] Getting Place IDs comes under requested radius ####*/
			return $arrIDs;
		//}	
		//else
			//return null;
	}
	
	public function like($pixie,$data)
	{
		$response['status'] = false;
		// Creating DB connection
		$con = $this->makeConnection($pixie,'PDO');
		
		
	}
	
	public function comment($pixie,$data)
	{
		// Creating DB connection
		$con = $this->makeConnection($pixie,'PDO');
		
		$url = 'https://graph.facebook.com/v2.1/'.$data['post_id'].'/comments';
		$params = array(
					"message" => "Clean India Campaign8",
					"access_token" => $data['access_token']
				);
		$data2 = http_build_query($params);
		$context = array(
		  'http' => array(
			'method' => "POST",
			'header'  => "Content-Type:application/x-www-form-urlencoded",
			'content'	=> $data2
		  )
		);
		$context = stream_context_create($context);
		$response1 = file_get_contents("https://graph.facebook.com/v2.1/".$data['post_id']."/comments", false, $context);
		
		$response['status'] = true;
			
	}
	
	
	public function create($pixie,$data)
	{
		$con = $this->makeConnection($pixie,'PDO');
		$arr = $arrprofile = array();
				
		if(!empty($data['fb_id']))
			$arr['fb_id'] = $arrprofile['fb_id'] = $data['fb_id'];
		
		if(!empty($data['campaign_title']))
			$arr['campaign_title'] =  $data['campaign_title'];
		
		$num = 0;
		$num = $con->query('count')->table('user_profile')->where('fb_id',$arr['fb_id'])->execute();
		$newprofile = false;
		
		if(!empty($data['lat']) && is_numeric($data['lat']))
			$arr['lat'] = $data['lat'];
	
		if(!empty($data['lng']) && is_numeric($data['lng']))
			$arr['lng'] = $data['lng'];
		
		if($num==0)
		{
			if(isset($data['profilepics']) && !empty($data['profilepics']) && isset($data['fb_id']) && !empty($data['fb_id']))
			{
				$profilepics = $data['profilepics'];
				
				$profilepics = base64_decode($profilepics);
				
				$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
				$ctx = stream_context_create($options);
				file_put_contents('gs://clean-india/profilepics/'.$data["fb_id"].'.jpeg', $profilepics, 0, $ctx);
				
				$arrprofile['profile_pic'] = 'http://storage.googleapis.com/clean-india/profilepics/'.$data["fb_id"].'.jpeg';
			}
			
			if(isset($data['email']) && !empty($data['email']))
			{
				$arrprofile['email']= $data['email'];
			}
			$ws = $con->query('insert')->table('user_profile')->data($arrprofile)->execute();
		}
		
		$arr['status'] = "0";
		$date = date_create();
		$date = date_format($date,'Y-m-d H:i:s');	
		$arr['started_on'] = $date;
		
		$ws = $con->query('insert')->table('campaign')->data($arr)->execute();
		$temp['id'] = $con->insert_id();
		
		if(isset($data['beforepics']) && !empty($data['beforepics']))
		{
			$beforepics = $data['beforepics'];
			/*			
			$data1 = 'iVBORw0KGgoAAAANSUhEUgAAABwAAAASCAMAAAB/2U7WAAAABl'
			. 'BMVEUAAAD///+l2Z/dAAAASUlEQVR4XqWQUQoAIAxC2/0vXZDr'
			. 'EX4IJTRkb7lobNUStXsB0jIXIAMSsQnWlsV+wULF4Avk9fLq2r'
			. '8a5HSE35Q3eO2XP1A1wQkZSgETvDtKdQAAAABJRU5ErkJggg==';*/
			//$fp = fopen('gs://lavasa-stuff/incidents/img'.$data['user_id'], 'w');
			//fwrite($fp,$data1);
			//var_dump($fp);
			//fclose($fp);
			$beforepics = base64_decode($beforepics);
			
			$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
			$ctx = stream_context_create($options);
			$name = $temp['id'].'_'.rand(100,999).time().'.jpeg';
			$p=file_put_contents('gs://clean-india/beforepics/'.$name, $beforepics, 0, $ctx);
			//if($success)
			$arr['before_pics'] = 'http://storage.googleapis.com/clean-india/beforepics/'.$name;
			
		}
		
		$beforearr['before_pics']=$arr['before_pics'];
		$ws = $con->query('update')->table('campaign')->data($beforearr)->where('id',$temp['id'])->execute();
		
		$response['status']  = true;
		$response['campaignid']  = $temp['id'];
		//$response['data'] = $temp;
		return $response;
	}
	/*
	public function getLocation($lat,$lng)
	{
		$key = "AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
		$url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$lat.",".$lng."&key=".$key;
		$loc = file_get_contents($url);
		$decode = json_decode($loc);
		$location = $decode->results[0]->formatted_address;
		return $location;
	}*/
	
	public function update($pixie,$data)
	{
		$response = array();	
		$con = $this->makeConnection($pixie,'PDO');
		$fb_id=$access_token=$arr['final_pics']='';
		if(isset($data['id']) && !empty($data['id']))
		{
			if(isset($data['liked']) && $data['liked'] && isset($data['fb_id']) && $data['fb_id'])
			{	
				if($data['liked']==1)
				{
					$arr_campaign_like['campaign_id'] = $data['id'];
					$arr_campaign_like['fb_id'] = $data['fb_id'];
					
					$num=$con->query('count')->table('campaign_user_mapping')->where(array(array('fb_id','=',$data['fb_id']),array('campaign_id','=',$data['id'])))->execute();
							
					if($num==0)		
						$ws = $con->query('insert')->table('campaign_user_mapping')->data($arr_campaign_like)->execute();
					$response['status']  = true;
				}	
			}
			else
			{
				if(isset($data['fb_id']) && $data['fb_id'] && isset($data['access_token']) && $data['access_token'])
				{
					//$_SESSION['fb_id']=$data['fb_id'];
					$fb_id = $data['fb_id'];
					$access_token = $data['access_token'];
					
					$arr_profile['access_token']=$data['access_token'];
					$ws = $con->query('update')->table('user_profile')->data($arr_profile)->where('fb_id',$data['fb_id'])->execute();
				}
				
				$ws = $con->query('select')->fields('*')->table('campaign')->where('id',$data['id'])->execute();
				$id = $before_pics = $after_pics = '';
				
				if($ws)
				{
					foreach($ws as $val)
					{
						$id = $val->id;
						$before_pics = $val->before_pics;
						//$after_pics = $val->after_pics;
					}
				}	
				
				if($id)				
				{
					$date = date_create();
					$date = date_format($date,'Y-m-d H:i:s');	
					$arr['completed_on'] = $date;
					
					/*
					if(!empty($data['post_id']))
					{
						$arr['post_id'] = $data['post_id'];
					}*/
					
					if(isset($data['afterpics']) && $data['afterpics'])
					{
						$afterpics = $data['afterpics'];
						$afterpics = base64_decode($afterpics);
						
						$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
						$ctx = stream_context_create($options);
						$name = $id.'_'.rand(100,999).time().'.jpeg';
						$res = file_put_contents('gs://clean-india/afterpics/'.$name, $afterpics, 0, $ctx);
					
						$arr['after_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$name;
					}
					

					///////////////// IMAGE MERGE CODE  //////////////////
					//$path = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
					//echo $path.'\\assets\\views\\images\\1.jpg';die;
					
					if($before_pics && $arr['after_pics'])
					{
						//$img1_path = $path.'\\assets\\views\\images\\1.jpg';
						//$img2_path = $path.'\\assets\\views\\images\\2.jpg';
						
						$img1_path = $before_pics;
						$img2_path = $arr['after_pics'];

						list($img1_width, $img1_height) = getimagesize($img1_path);
						list($img2_width, $img2_height) = getimagesize($img2_path);

						$merged_width  = $img1_width + $img2_width;
						//get highest
						$merged_height = $img1_height > $img2_height ? $img1_height : $img2_height;

						$merged_image = @imagecreatetruecolor($merged_width, $merged_height);
						
						@imagealphablending($merged_image, false);
						@imagesavealpha($merged_image, true);

						$img1 = @imagecreatefromjpeg($img1_path);
						$img2 = @imagecreatefromjpeg($img2_path);
						
						//$img1_width = $img1_width < 450 ? $img1_width : 450;
						//$img2_width = $img2_width < 450 ? $img2_width : 450;
						
						@imagecopy($merged_image, $img1, 0, 0, 0, 0, $img1_width, $img1_height);
						//@imagecopyresized($merged_image, $img1, 0, 0, 0, 0, 450, $img1_height,$img1_width, $img1_height);
						//place at right side of $img1
						@imagecopy($merged_image, $img2, $img1_width, 0, 0, 0, $img2_width, $img2_height);
						//@imagecopyresized($merged_image, $img2, $img1_width, 0, 0, 0, 450, $img2_height,$img2_width, $img2_height);
						
						//save file or output to broswer
						$SAVE_AS_FILE = TRUE;
						if( $SAVE_AS_FILE ){
							$save_path = 'gs://clean-india/afterpics/final_copy.jpg';
							$r=imagejpeg($merged_image,$save_path);
							
							$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
							$ctx = stream_context_create($options);
							$name = 'final_'.rand(100,999).time().'.jpeg';
							
							copy($save_path,'gs://clean-india/afterpics/'.$name,$ctx);
							$arr['final_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$name;
						}else{
							//header('Content-Type: image/png');
							$finalImg = @imagejpeg($merged_image);
							
							$options = [ "gs" => [ "Content-Type" => "image/png" ,"acl"=>"public-read"]];
							$ctx = stream_context_create($options);
							$name = 'final_'.rand(100,999).time().'.png';
							file_put_contents('gs://clean-india/afterpics/'.$name, $finalImg, 0, $ctx);
							
							$arr['final_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$name;
						}
						
					}	
					
					$arr['status'] = '1';
					$ws = $con->query('update')->table('campaign')->data($arr)->where('id',$id)->execute();
					
					
					/* POSTING on User Wall 
					
					 $params = array(
						"url" => "http://storage.googleapis.com/clean-india/beforepics/1_2911413457153.jpeg",
						"message" => "Clean India Campaign Test 6",
						"access_token" => $data['access_token']
						
					);
					$data1 = http_build_query($params);
					$context = array(
					  'http' => array(
						'method' => "POST",
						'header'  => "Content-Type: application/x-www-form-urlencoded",
						'content'	=> $data1
					  )
					);
					$context = stream_context_create($context);
					$response1 = file_get_contents("https://graph.facebook.com/v2.1/me/photos", false, $context);
					
					
					 End Posting on user wall */
					
					/* Posting on page wall */
					//"http://storage.googleapis.com/clean-india/afterpics/36_9801413537225.jpeg"
					
					//echo $arr['after_pics'];die;
					$params = array(
						"url" => $arr['final_pics'],
						"message" => "#swatchbharat I have just completed a challenge #".$id.", on Clean India Campaign.",
						"access_token" => $data['access_token']
					);
					$data2 = http_build_query($params);
					$context = array(
					  'http' => array(
						'method' => "POST",
						'header'  => "Content-Type:  application/x-www-form-urlencoded",
						'content'	=> $data2
					  )
					);
					$context = stream_context_create($context);
					$response1 = file_get_contents("https://graph.facebook.com/v2.1/1513506835555076/photos", false, $context);
					
					/* End Posting on page wall */
					$arr_postid = array();
					$parse = json_decode($response1);
					
					if(isset($parse->id))
						$arr_postid['post_id'] = $parse->id;
					
					if($arr_postid['post_id'])
						$ws = $con->query('update')->table('campaign')->data($arr_postid)->where('id',$id)->execute();
					
					/* Tagging myself */
					
					if($parse->id && $fb_id && $access_token)
					{
						$url = 'https://graph.facebook.com/v2.1/'.$parse->id.'/tags';
						
						$params = array(
							"tags" => "[{'tag_uid': '".$fb_id."'}]",
							"access_token" => $access_token
						);
						$data2 = http_build_query($params);
						$context = array(
						  'http' => array(
							'method' => "POST",
							'header'  => "Content-Type:application/x-www-form-urlencoded",
							'content'	=> $data2
						  )
						);
						$context = stream_context_create($context);
						$response1 = file_get_contents($url, false, $context);
					}			
					
					/* Tagging myself */
					
				
				}
				$response['status']  = true;	
			}
		}
		else
		{
			$response['status'] = false;
			$response['message'] = 'INVALID_PARAMETERS';
		}	
		
		return $response;
 
	}
	
	public function delete($pixie,$data)
	{
		/*$response['status'] = false;
		$before_pic = $ws = '';
		
		$con = $this->makeConnection($pixie,'PDO');
		if(isset($data['id']) && !empty($data['id']))
		{
			$ws = $con->query('select')->fields('before_pics')->table('campaign')->where('id',$data['id'])->execute();
			$con->query('delete')->table('campaign')->where('id',$data['id'])->execute();
		}	
		
		if(!empty($ws))
		{
			foreach($ws as $val)
			{
				$before_pic = $val->before_pics; 
			}
		}	
		
		if(is_file($before_pic))
		{
			unlink($before_pic);
			$response['status'] = true;
			$response['message'] = 'RECORD_DELETED';
		}
		
		return $response;
		*/
	}
}	//end of class	
	?>