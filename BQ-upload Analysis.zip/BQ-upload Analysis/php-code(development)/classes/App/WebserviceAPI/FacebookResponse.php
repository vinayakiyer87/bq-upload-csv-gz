<?php
namespace App\WebserviceAPI;
class FacebookResponse {
	
	public function read($pixie,$data)
	{
		$this->err = 'INVALID_PARAMETERS';
		$detailData = array();	
		$response['status'] = false;
		$this->countVal = 0;
		$this->type = $this->limit = $this->offset = $this->order_by = $this->radiusCompare = $rad = $cat = '';
		$ext = array();
		
		//if(!empty($data['user_id']))
		//	$this->confirmed = $data['user_id'];
		
		if(!empty($data['lat']) && !empty($data['lng']) && is_numeric($data['lat']) && is_numeric($data['lng']))
		{
			if(!empty($data['radius']) && is_numeric($data['radius']))
			{
				$rad = $data['radius'];
			}
		
			// Creating DB connection
			$con = $this->makeConnection($pixie,'PDO');
			
			// Getting NearBy Incidents' IDs 
			$getIds = $this->getCampaigns($pixie,$con,$data['lat'],$data['lng'],$rad,$cat);//$data['category'],$data['offset'],$data['limit']);
		
			$response['status'] = true;
			
			if(sizeof($getIds)<=0)
			{
				$response['message'] = 'NO_DATA_FOUND';
			}
			else
				$response['data'] = $getIds;
		}		
		return $response;
	}
	
	public function makeConnection($pixie,$driver)
	{
		$connection = '';
		if(!empty($driver) && is_object($pixie))
		{
			switch($driver)
			{
				case 'PDO':
					$connection = $pixie->db->get('PDO');
					break;
				case 'datastore':
					$connection = $pixie->orm->get('Incident');
					break;
					
			}
		}
		return $connection?$connection:null;
	}
	
	public function getCampaigns($pixie,$con,$lat,$lng,$radius,$category)//,$offset,$limit)
	{
		$arrIDs = array();
		$categoryStr = '';
		
		if(!empty($lat) && !empty($lng))
		{	
			if(!empty($radius) && is_numeric($radius))
				$this->radius      = ABS($radius);
			else
				$this->radius = 0;
			
			$orderBy      = " order by distance";
				
			if(isset($offset) && isset($limit) && is_numeric($offset) && is_numeric($offset))
				$this->limit      = " LIMIT ".ABS($offset).",".ABS($limit);
			
			if(!empty($this->radius) && $this->radius!=0)
				$this->radiusCompare = " HAVING distance<=".$this->radius;
			
			
			if(!empty($category))
				$categoryStr = " category ='".trim(strtolower($category))."' AND ";
				
			/**if(!empty($type))
			{
				$this->type = " AND type='".addslashes($type)."'";
				
				if(strtolower(trim($type))=='featured')
					$this->type = " AND is_featured='1'";
				if(strtolower(trim($type))=='all')
					$this->type = "";
					
			}*/
			
			/*#### [Begin] Calculating total number of records ####*/
			/*
			$count = $pixie->db->expr('SELECT COUNT(id) AS CNT FROM incidentgeos WHERE '.$categoryStr.' is_active=\'1\' AND (1000 * 6371 * 2 * ASIN(SQRT(POWER(SIN(('.ABS($lat).' - ABS(incidentgeos.lat)) * PI()/180 / 2), 2) + COS('.ABS($lat).' * PI()/180 ) * COS(ABS(incidentgeos.lat) * PI()/180) * POWER(SIN(('.ABS($lng).' - incidentgeos.lng) * PI()/180 / 2), 2))))<='. $this->radius  );
		   
			//print_r($count);die;
			$ws = $con->query('select')->fields('CNT')->table($count)->execute();
			 */
			
			/*#### [End] Calculating total number of records ####*/
			/*
			$cnt = 0;
			if(!empty($ws))
			{
				foreach($ws as $val)
				{
					$cnt = $val->CNT;
				}
			}
			*/
			/*#### [Begin] Getting Place IDs comes under requested radius  ####*/
			//if($cnt>0)
			//{
				$var = $pixie->db->expr('SELECT *, 1000 * 6371 * 2 * ASIN(SQRT(POWER(SIN(('.ABS($lat).' - ABS(campaign.lat)) * PI()/180 / 2), 2) + COS('.ABS($lat).' * PI()/180 ) * COS(ABS(campaign.lat) * PI()/180) * POWER(SIN(('.ABS($lng).' - campaign.lng) * PI()/180 / 2), 2))) AS distance FROM campaign WHERE 1 '. $this->radiusCompare . $orderBy  );
					
				$ws = $con->query('select')->fields('*','distance')->table($var)->execute();
				
				if(!empty($ws))
				{
					
					foreach($ws as $val)
					{
						$temp =array();
						if(!empty($val->id))
							$temp['id'] = $val->id; 
						if(!empty($val->fb_id))
							$temp['fb_id'] = $val->fb_id; 
						if(!empty($val->lat))
							$temp['lat'] = $val->lat; 
						if(!empty($val->lng))	
							$temp['lng'] = $val->lng;
						if(isset($val->status))						
							$temp['status'] = $val->status; 
						$temp['before_pics'] = '';
						if(!empty($val->before_pics))
							$temp['before_pics'] = $val->before_pics;
						$temp['after_pics'] = '';
						if(!empty($val->after_pics))
							$temp['after_pics'] = $val->after_pics; 
						/*if(!empty($val->started_on))
							$temp['started_on'] = $val->started_on; 
						if(!empty($val->completed_on))
							$temp['completed_on'] = $val->completed_on; */
						$arrIDs[] = $temp;
					}
				}
			//}
			
			/*#### [End] Getting Place IDs comes under requested radius ####*/
			return $arrIDs;
		}	
		else
			return null;
	}
	
	public function getIncidentsNearBy($pixie,$con,$val,$source,$limit,$offset,$order_by)
	{
		$incident_count = $con->find_all();
		$cnt = 0;
		foreach($incident_count as $val)
		{
			$total_count = $cnt;
			$cnt++;
		}
		$this->totalCount = $total_count;
		$incident_reported_count = $pixie->orm->get('Incident')->where('status','=','Reported')->find_all();
		
		if(isset($incident_reported_count))
		{
		$reported_count = 0;
		foreach($incident_reported_count as $val)
		{
			$rcnt = $reported_count;
			$reported_count++;
		}
		$this->ReportedCount = $rcnt;
		}
		else{
		$this->ReportedCount = 0;
		}
		$incident_resolved_count = $pixie->orm->get('Incident')->where('status','=','Resolved')->find_all();
		//print_r($incident_resolved_count); die;
		if(isset($incident_resolved_count))
		{
			$resolved_count = 0;
			foreach($incident_resolved_count as $val)
			{
				$resolved_count++;
			}
			$this->ResolvedCount = $resolved_count;
		}
		else{
			$this->ResolvedCount = 0;
		}
		$incident_progress_count = $pixie->orm->get('Incident')->where('status','=','Progress')->find_all();
		//print_r($incident_resolved_count); die;
		$progress_count = 0;
		if(isset($incident_progress_count))
		{
			foreach($incident_progress_count as $val)
			{
				$progress_count++;
			}
			$this->ProgressCount = $progress_count;
		}
		else{
			$this->ProgressCount = $progress_count;
		}
		
		
		$temp = $photo = $nearBy = $finalArr = array();
		if(!empty($con) && $source=='all')
		{
		
				if(isset($order_by) && $order_by == 'type')
				{
				$nearBy = $con->order_by('category','asc')->limit($limit)->offset($offset)->find_all();
				}
				elseif(isset($order_by) && $order_by == '-type')
				{
				$nearBy = $con->order_by('category','desc')->limit($limit)->offset($offset)->find_all();
				}
				elseif(isset($order_by) && $order_by == 'status')
				{
				$nearBy = $con->order_by('status','asc')->limit($limit)->offset($offset)->find_all();
				}
				elseif(isset($order_by) && $order_by == '-status')
				{
				$nearBy = $con->order_by('status','desc')->limit($limit)->offset($offset)->find_all();
				}
				else
				{
				$nearBy = $con->limit($limit)->offset($offset)->find_all();
				}
				
		}
		else
		{
			if(!empty($con) && !empty($val) && is_numeric($val))
			{
				$nearBy = $con->where('id','=',$val)->find_all();
			}	
		}	
		
			if(sizeof($nearBy)>0)
			{	
				$i=$offset+1;
				foreach ($nearBy as $newval)
				{
					$temp = $photo = $temp['comments'] = array();
					$temp['status'] = $temp['subcat'] = $temp['assigned_to'] = $temp['action_on']	= $temp['img_url'] = $temp['location'] = $temp['title'] = '';	
					$temp['confirmed_by_count'] = $temp['comments_count'] = 0;
					$temp['confirmed_by'] = false;
					$temp['sr_no']=$i;
					if(isset($newval->id) && $newval->id!='null')
						$temp['id']=$newval->id;
					if(isset($newval->user_id) && $newval->user_id!='null')
						$temp['user_id']=$newval->user_id;
					if(isset($newval->title) && $newval->title!='null')	
						$temp['title']=$newval->title;
					if(isset($newval->location) && $newval->location!='null')	
						$temp['location']=$newval->location;
					if(isset($newval->lat) && $newval->lat!='null')
						$temp['lat']=$newval->lat;
					if(isset($newval->lng) && $newval->lng!='null')
						$temp['lng']=$newval->lng;
					if(isset($newval->category) && $newval->category!='null')
						$temp['category']=$newval->category;
					if(isset($newval->description) && $newval->description!='null')
						$temp['description']=$newval->description;
					if(isset($newval->img_url) && $newval->img_url!='null')
						$temp['img_url']=$newval->img_url;
					if(isset($newval->reported_on) && $newval->reported_on!='null')
						$temp['reported_on'] = date('d M Y',strtotime($newval->reported_on));
					if(isset($newval->action_on) && $newval->action_on!='null')
						$temp['action_on']=$newval->action_on;
					if(isset($newval->assigned_to) && $newval->assigned_to!='null')
						$temp['assigned_to']=$newval->assigned_to;
					if(isset($newval->subcat) && $newval->subcat!='null')
						$temp['subcat']=$newval->subcat;
					if(isset($newval->status) && $newval->status!='null')
						$temp['status']=$newval->status;
					
					
					if(isset($newval->confirmed_by) && $newval->confirmed_by!='null')
					{	
						if(!empty($this->confirmed))
						{
							if(in_array($this->confirmed,$newval->confirmed_by))
								$temp['confirmed_by'] = True;
							else	
								$temp['confirmed_by'] = False;
						}
						$temp['confirmed_by_count'] = sizeof($newval->confirmed_by);
					}
					
					if(isset($newval->comments) && $newval->comments!='null')
					{
						//$temp['comments'] = $newval->comments;
						$countComments = 0; 
						if(sizeof($newval->comments))
						{
							foreach($newval->comments as $valComments)
							{
								$Arr = json_decode($valComments);
								//print_r($Arr);die;
								if(isset($Arr->text))	
									$commentsArr['text'] = $Arr->text;
								if(isset($Arr->updated_on))	
									$commentsArr['updated_on'] = $Arr->updated_on;
								if(isset($Arr->updated_by))	
									$commentsArr['updated_by'] = $Arr->updated_by;
								
								$temp['comments'][] = $commentsArr;	
							}
							krsort($temp['comments']);
							array_splice($temp['comments'],5);
						}
						$temp['comments_count'] = sizeof($newval->comments);
					}
					
					/*
					$temp['image'] = '';
				
					if(!empty($newval->user_id))
					{
					///https://console.developers.google.com/m/cloudstorage/b/lavasa-stuff/o/incidents/imgWRRFGJJ454867U.jpeg
						$fileURL = 'https://console.developers.google.com/m/cloudstorage/b/lavasa-stuff/o/incidents/img'.$newval->user_id.'.jpeg';
						//if(is_file($fileURL))
						///{
							echo $fileURL;
							$fp = fopen('gs://lavasa-stuff/incidents/img'.$newval->user_id.'.jpeg', 'rb');
							$imgData = '';
							if($fp)
							{
								$imgData = stream_get_contents($fp);
								//$imgData = fread($fp,sizeof('gs://lavasa-stuff/incidents/img'.$newval->user_id));
								fclose($fp);
								$temp['image'] = base64_encode($imgData);
							}
							$temp['image'] = $fileURL;
						//}
					}	
					*/
				$this->countVal = ++$this->countVal;
				$i++;
				$finalArr[] = $temp;
				}		
			}
		if(sizeof($finalArr)>1)
			return $finalArr;
		else	
			return $temp;	
	}
	
	
	
	public function create($pixie,$data)
	{
		echo "<script> document.body.style.background = ('red');</script>";
		die;
		$con = $this->makeConnection($pixie,'PDO');
		$arr = $arrprofile = array();
				
		if(!empty($data['fb_id']))
			$arr['fb_id'] = $arrprofile['fb_id'] = $data['fb_id'];
		
		
		
		$response['status']  = true;
		$response['campaignid']  = $temp['id'];
		
		return $response;
	}
	/*
	public function getLocation($lat,$lng)
	{
		$key = "AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo";
		$url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=".$lat.",".$lng."&key=".$key;
		$loc = file_get_contents($url);
		$decode = json_decode($loc);
		$location = $decode->results[0]->formatted_address;
		return $location;
	}*/
	
	public function update($pixie,$data)
	{
		$response = array();	
		if(!empty($data['id']) && !empty($data['id']))
		{
			$con = $this->makeConnection($pixie,'PDO');
			$ws = $con->query('select')->fields('id')->table('campaign')->where('id',$data['id'])->execute();
			$id = '';
			
			if(!empty($ws))
			{
				foreach($ws as $val)
				{
					$id = $val->id;
				}
			}	
			if(!empty($id))				
			{
				$date = date_create();
				$date = date_format($date,'Y-m-d H:i:s');	
				$arr['completed_on'] = $date;
				
				if(!empty($data['afterpics']))
				{
					$afterpics = $data['afterpics'];
					$afterpics = base64_decode($afterpics);
					
					$options = [ "gs" => [ "Content-Type" => "image/jpeg" ,"acl"=>"public-read"]];
					$ctx = stream_context_create($options);
					file_put_contents('gs://clean-india/afterpics/'.$id.'.jpeg', $afterpics, 0, $ctx);
					
					$arr['after_pics'] = 'http://storage.googleapis.com/clean-india/afterpics/'.$id.'.jpeg';
				}
				
				$arr['status'] = '1';
				$ws = $con->query('update')->table('campaign')->data($arr)->where('id',$id)->execute();
				
				$response['status']  = true;
			}
		}
		else
		{
			$response['status'] = false;
			$response['message'] = 'INVALID_PARAMETERS';
		}	
		
		return $response;
 
	}
}	//end of class	
	?>