<?php

namespace AuthN\Login;

abstract class Provider {

public function logout()
{
	session_destroy();
}

}
