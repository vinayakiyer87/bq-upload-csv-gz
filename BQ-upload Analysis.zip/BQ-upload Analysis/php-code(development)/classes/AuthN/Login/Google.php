<?php

namespace AuthN\Login;

class Google extends Provider {

public $token;
public $user_id;
public $code;
public $clientId;
public $client_secret; 
public $redirect_uri;
public $api_url;
public $token_url;
public $grant_type;
public $first_name;
public $last_name;

public function __construct()
{
	$this->clientId = '50021251974-j2un91ho8ho2fljmkuhhmt16mb2slq43.apps.googleusercontent.com';
	$this->client_secret = 'wu7S95Ra5v2U9Ulz6fEXh1D0';
	$this->api_url='';
	$this->redirect_uri='http://lavasa-dev.appspot.com/Google/Authorize';
	$this->token_url='https://accounts.google.com/o/oauth2/token';
}


public function fetch_code()
{
	$url = "https://accounts.google.com/o/oauth2/auth";
$params = array(
    "response_type" => "code",
    "client_id" => $this->clientId,
    "redirect_uri" => $this->redirect_uri,
    "scope" => "https://www.googleapis.com/auth/userinfo.email"
    );
    $request_to = $url . '?' . http_build_query($params);
    header("Location: " . $request_to);
}

public function generate_token()
{
	$this->grant_type = 'authorization_code';

    $params = array(
        "code" => $this->code,
        "client_id" => $this->clientId,
        "client_secret" => $this->client_secret,
        "redirect_uri" => $this->redirect_uri,
        "grant_type" => $this->grant_type
    );
	$data = http_build_query($params);
	$context = array(
	  'http' => array(
	    'method' => "POST",
		'content'	=> $data
	  )
	);
	$context = stream_context_create($context);
	$response = file_get_contents($this->token_url, false, $context);
	if(isset($response))
	{
		$output = json_decode($response);
		$this->token = $output->access_token;
		$expire = $output->expires_in;
		$current_time = time();
		$this->expire = $current_time + $expire;
		if(isset($this->token))
		{
			$_SESSION['google_token'] = $this->token;
			$_SESSION['google_expire'] = $this->expire;
			$_SESSION['login_provider'] = 'Google';
		}
	}
	else{
		return false;
	}

}

public function fetch_userid()
{
	$url = 'https://www.googleapis.com/oauth2/v1/userinfo?access_token='.$this->token;
	$user_data = file_get_contents($url);
	if(isset($user_data))
	{
		$user_record = json_decode($user_data);
		if(isset($user_record->email))
		{
			$this->gid = $user_record->email;
			$this->first_name = $user_record->given_name;
			$this->last_name = $user_record->family_name;
			$this->name = $user_record->name;
			return $this->gid;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}
}
public function logout()
{
	parent::logout();
}
}
