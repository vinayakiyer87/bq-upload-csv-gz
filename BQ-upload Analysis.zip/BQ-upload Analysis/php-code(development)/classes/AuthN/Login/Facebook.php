<?php

namespace AuthN\Login;

class Facebook extends Provider {

public $token;
public $user_id;
public $code;
public $clientId;
public $client_secret;
public $redirect_uri;
public $api_url;
public $token_url;
public $grant_type;
public $extendedPermissions;
public $fid;
public $first_name;
public $last_name;

public function __construct()
{
	$this->clientId='616574625121742';
	$this->client_secret = '1a7a15477ceec6065c8060cdcc660a0e';
	$this->api_url='';
	$this->redirect_uri='http://clean-india-dev.appspot.com/Facebook/authorize';
	$this->token_url = 'https://graph.facebook.com/oauth/access_token';
	$this->extendedPermissions = 'email,publish_stream,manage_pages,offline_access';
}


public function fetch_code()
{
	$url = "https://graph.facebook.com/oauth/authorize";
	$params = array(
    "client_id" => $this->clientId,
    "redirect_uri" => $this->redirect_uri,
    "scope" => $this->extendedPermissions
    );
    $request_to = $url . '?' . http_build_query($params);
    header("Location: " . $request_to);
}

public function generate_token()
{
    $params = array(
        "code" => $this->code,
        "client_id" => $this->clientId,
        "client_secret" => $this->client_secret,
        "redirect_uri" => $this->redirect_uri
    );
	$data = http_build_query($params);
	$context = array(
	  'http' => array(
	    'method' => "POST",
		'content'	=> $data
	  )
	);
	$context = stream_context_create($context);
	$response = file_get_contents($this->token_url, false, $context);
	$response_data = parse_str($response);
	$this->token = $access_token;
	$expire_time = $expires;
	$current_time = time();
	$this->expire = $current_time + $expire_time;
	if(isset($this->token))
	{
		$_SESSION['facebook_token'] = $this->token;
		$_SESSION['facebook_expire'] = $this->expire;
		$_SESSION['login_provider'] = 'Facebook';
	}
	
}

public function fetch_userid()
{
	$url = 'https://graph.facebook.com/me';
    $user_params = array(
            'access_token'  => $this->token,
            ); 
   // $user_data = http_build_query($user_params);
    $request_to = $url . '?' . http_build_query($user_params);
	$record = file_get_contents($request_to);
	if(isset($record))
	{
		$record_data = json_decode($record);
		
		
		if(isset($record_data->email))
		{
		$this->fid = $record_data->email;
		$this->first_name = $record_data->first_name;
		$this->last_name = $record_data->last_name;
		$this->name = $record_data->name;
		}
		else{
			return false;
		}
	}
	else{
			return false;
		}
}
public function logout()
{
	parent::logout();
}
}
