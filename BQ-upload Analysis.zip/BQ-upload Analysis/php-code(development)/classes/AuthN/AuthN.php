<?php

namespace AuthN;

class AuthN {

	public $user;

	public function __construct() {
	session_start();
	}

	public function user() {
	
		if(isset($_SESSION))
		{
			if((isset($_SESSION['login_provider'])) && ($_SESSION['login_provider'] == 'Google'))
			{
				if(isset($_SESSION['google_token']))
				{
					$url = 'https://www.googleapis.com/oauth2/v1/userinfo?access_token='.$_SESSION['google_token'];
					$user_data = file_get_contents($url);
					if(isset($user_data))
					{
						$user_record = json_decode($user_data);
						if(isset($user_record->email))
						{
							$email_id = $user_record->email;
							$this->user = new \App\Model\User;
							$this->user->setLoginProvider('google');
							$this->user->setLoginId($user_record->email);
							$this->user->FetchUserByLoginId();
							return $this->user;

						}
						else{
							return false;
						}
					}
					else{
						return false;
					}
					
				}
			}
			elseif((isset($_SESSION['login_provider'])) && ($_SESSION['login_provider'] == 'Facebook'))
			{
			if(isset($_SESSION['facebook_token']))
				{
					$url = 'https://graph.facebook.com/me';
				    $user_params = array(
				            'access_token'  => $_SESSION['facebook_token'],
				            ); 
				    $request_to = $url . '?' . http_build_query($user_params);
					$record = file_get_contents($request_to);
					if($record)
					{
						$record_data = json_decode($record);
						
						if(isset($record_data->email))
						{
							$email_id = $record_data->email;
							$name = $record_data->name;
							$this->user = new \App\Model\User;
							$this->user->setLoginProvider('facebook');
							$this->user->setLoginId($record_data->email);
							$this->user->FetchUserByLoginId();
							return $this->user;
						}
						else{
							return false;
						}
					}
					else{
							return false;
						}
					
				}
			}
		}
return $this->user;

}
public function logout()
{
	if(isset($_SESSION))
		{
			if((isset($_SESSION['login_provider'])) && ($_SESSION['login_provider'] == 'Google'))
			{
				$this->google = new \AuthN\Login\Google;
				$this->google->logout();
			}
			elseif((isset($_SESSION['login_provider'])) && ($_SESSION['login_provider'] == 'Facebook'))
			{
				$this->facebook = new \AuthN\Login\Facebook;
				$this->facebook->logout();
			}
		}
}
}
