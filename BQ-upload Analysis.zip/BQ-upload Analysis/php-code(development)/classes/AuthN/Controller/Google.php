<?php

namespace AuthN\Controller;

/**
 * Abstract Facebook login controller. To use it you need to extend this class
 * and override the new_user() method, which handles the situation when a user
 * logs in with your app for the very first time (basically youi need to register him
 * at that point).
 *
 * It can be used both for popup login and page login.
 * To use the page login, make a link pointing to the controllers 'index' action,
 * for pupup login open a popup that points to its 'popup' action.
 * Optionally you can pass a ?return_url =<url> parameter to specify where to redirect the
 * user after he is logged in. You can also specify a default redirect url in the auth.php config file.
 */
abstract class Google extends \PHPixie\Controller {
	private $google;
	private $user;
	public function before() {
	session_start();
	$this->google = new \AuthN\Login\Google;
	}
	
	public function action_index() {
			$this->google->fetch_code();
	}

	public function action_login() {

	
	}

	public function action_authorize() {
		if((isset($_GET['code'])) && (!empty($_GET['code'])))
		{
			$this->google->code = $_GET['code'];//get from request params	
			$this->google->generate_token();
			if(isset($this->google->token))
			{	
				$this->google->fetch_userid();
				if(isset($this->google->gid))
				{
					$this->user = new \App\Model\User;
					$this->user->setLoginProvider('google');
					$this->user->setLoginId($this->google->gid);
					$this->user->setFirstName($this->google->first_name);
					$this->user->setLastName($this->google->last_name);
					$this->user->setName($this->google->name);
					if($this->user->FetchUserByLoginId())
						{					
							$user_role = $this->user->getRole();
						}
					else
						{//Insert the user
						$this->user->saveNewUser();
						$user_role = 'general';
						}
					if(isset($user_role))
					{
						switch($user_role)
						{
							case 'admin' : $this->redirect('/Admin'); break;
							case 'customer' : $this->redirect('/Portal');break;
							case 'general' : $this->redirect('/Portal'); break;
							default : $this->redirect('/Login');
						}
					}
				}
			}
		}
		
		elseif(isset($_GET['error']))
			{
				$this->redirect('/Login');
			}
		else{
			$this->redirect('/Login');
		}
	
	}
}
