<?php

namespace AuthN\Controller;

/**
 * Abstract Facebook login controller. To use it you need to extend this class
 * and override the new_user() method, which handles the situation when a user
 * logs in with your app for the very first time (basically youi need to register him
 * at that point).
 *
 * It can be used both for popup login and page login.
 * To use the page login, make a link pointing to the controllers 'index' action,
 * for pupup login open a popup that points to its 'popup' action.
 * Optionally you can pass a ?return_url =<url> parameter to specify where to redirect the
 * user after he is logged in. You can also specify a default redirect url in the auth.php config file.
 */
abstract class Facebook extends \PHPixie\Controller {
	private $facebook;
	private $user;
	public function before() {
	session_start();
	$this->facebook = new \AuthN\Login\Facebook;
	}
	
	public function action_index() {
	//print_r($this->request->param('token'));die;
	$url = 'https://graph.facebook.com/me';
    $user_params = array(
            'access_token'  => $this->request->param('token'),
			); 
   
    $request_to = $url . '?' . http_build_query($user_params);
	$record = file_get_contents($request_to);
	//print_r($record);
	//die;
	$_SESSION['postid'] = $_SESSION['access_token'] = '';
	if($this->request->param('id'))
	{
		$_SESSION['postid'] = $this->request->param('id');
	}
	if($this->request->param('token'))
	{
		$_SESSION['access_token'] = $this->request->param('token');
	}
	
	/*
	 $params = array(
        "url" => "http://storage.googleapis.com/clean-india/beforepics/1_2911413457153.jpeg"
        
    );
	$data = http_build_query($params);
	$context = array(
	  'http' => array(
	    'method' => "POST",
		'header'  => "Content-Type: application/x-www-form-urlencoded",
		'content'	=> $data
	  )
	);
	$context = stream_context_create($context);
	$response = file_get_contents("https://graph.facebook.com/v2.1/me/photos", false, $context);
	

	die;*/  
	
	
	
	 $params = array(
        "message" => "hello"
    );
	$data = http_build_query($params);
	$context = array(
	  'http' => array(
	    'method' => "POST",
		'header'  => "Content-Type: application/x-www-form-urlencoded",
		'content'	=> $data
	  )
	);
	$context = stream_context_create($context);
	$response = file_get_contents("https://graph.facebook.com/v2.1/me/feed", false, $context);
	
	///v2.1/me/feed HTTP/1.1
//Host: graph.facebook.com

//message=This+is+a+test+message
	die;
	
	
	header("location:http://localhost:8080/Fbresponse/");die;	
	//	$this->facebook->fetch_code();
	}

	public function action_login() {
	
	}

	public function action_authorize() { 
		if((isset($_GET['code'])) && (!empty($_GET['code'])))
		{
			$this->facebook->code = $_GET['code'];//get from request params	
			$this->facebook->generate_token();
			if(isset($this->facebook->token))
			{	
				
				$this->facebook->fetch_userid();
				if(isset($this->facebook->fid))
				{
					$arr = array("FBID"=>$this->facebook->fid,"first_name"=>$this->facebook->first_name,"last_name"=>$this->facebook->last_name);
					
					
					$result = json_encode($arr);
					
					
					header("location:http://clean-india-dev.appspot.com/Fbresponse/");die;
					
					//print_r($result);
					//die;
					/*
					$url = 'https://graph.facebook.com/v2.1/738117832912924/feed';
					
					$postdata = http_build_query(
								array(
									'access_token' => $this->facebook->token,
									'message' => 'New Testing'
								)
							);

							$opts = array('http' =>
								array(
									'method'  => 'POST',
									'header'  => 'Content-type: application/x-www-form-urlencoded',
									'content' => $postdata
								)
							);

							$context  = stream_context_create($opts);
					$record = file_get_contents($url,false,$context);
					*/
					// die;
					//print_r($record);
					/*$this->user = new \App\Model\User;
					$this->user->setLoginProvider('facebook');
					$this->user->setLoginId($this->facebook->fid);
					$this->user->setFirstName($this->facebook->first_name);
					$this->user->setLastName($this->facebook->last_name);
					$this->user->setName($this->facebook->name);
					if($this->user->FetchUserByLoginId())
						{					
							$user_role = $this->user->getRole();
						}
					else
						{//Insert the user
						$this->user->saveNewUser();
						$user_role = 'general';
						}
					if(isset($user_role))
					{
						switch($user_role)
						{
							case 'admin' : $this->redirect('/Admin'); break;
							case 'customer' : $this->redirect('/Portal');break;
							case 'general' : $this->redirect('/Portal'); break;
							default : $this->redirect('/Login');
						}
					}*/
				}
			}
		}
		elseif(isset($_GET['error']))
			{
				$this->redirect('/Login');
			}
		else{
			$this->redirect('/Login');
		}

	}
}
