<?php
class RatingTest extends PHPUnit_Framework_TestCase
{
	
	protected function setUp(){
		$pixie = $this->pixie = new \PHPixie\Pixie();
		$this->pixie-> app_namespace = 'App\\';
		$pixie->db = new \PHPixie\DB($pixie);
		$pixie->orm = new \PHPixie\ORM($pixie);
     	$this->pixie->config->set('db.default.driver', 'datastore');
		$this->pixie->config->set('db.default.application-id', 'lavasa-dev');
		$this->pixie->config->set('db.default.service-account-name', '50021251974-0kli84jjumrfb9f38bf9mg0scgjh3b4m@developer.gserviceaccount.com');
		$this->pixie->config->set('db.default.private-key', file_get_contents('../../web/9dff04fbb97923cc383f49d5287c59d5a0449b3d-privatekey.p12'));
		$this->pixie->config->set('db.default.dataset-id', 'lavasa-dev');
		
	}
	public function testGetGoogleUserImageUrl()
	{
		$RatingObj  = new \App\WebserviceAPI\Rating($this->pixie);
		$RatingObj->apiKey = 'AIzaSyAzAYkAVXp2GkQeCEY1GLyQw8N0XfNmsVo';
		$RatingObj->userID = '116175501145734706457';
		$response = $RatingObj->GetGoogleUserImageUrl($RatingObj->userID);
		$this->assertArrayHasKey('url',$response);
	}

	public function testGetFacebookUserImageUrl()
	{
		$RatingObj  = new \App\WebserviceAPI\Rating($this->pixie);
		$RatingObj->client_id = '594236164024206';
		$RatingObj->client_secret = '7b464d1da6f24ef1512b52a2fd77087c';
		$RatingObj->fid = '842128055806011';
		$response = $RatingObj->GetFacebookUserImageUrl($RatingObj->fid);
		$this->assertArrayHasKey('url',$response);
	}

	public function testRead()
	{
		$RatingObj  = new \App\WebserviceAPI\Rating($this->pixie);
	}
	public function testCreate()
	{
		$RatingObj  = new \App\WebserviceAPI\Rating($this->pixie);
	}
	
}
