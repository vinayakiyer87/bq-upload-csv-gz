<?php
class AttractionDetail_Test extends PHPUnit_Framework_TestCase
{
	private $dbconn,$AttractionDetailObj;
	public static $conn,$data;
	protected function setUp(){
		$this->dbconn = new PDO('mysql:host=localhost;dbname=geodata','root','');
		$this->dbconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$pixie = $this->pixie = new \PHPixie\Pixie();
		$this->pixie-> app_namespace = 'App\\';
		$pixie->db = new \PHPixie\DB($pixie);
		$pixie->orm = new \PHPixie\ORM($pixie);
        $this->pixie->config->set('db.default.driver', 'datastore');
		$this->pixie->config->set('db.default.application-id', 'lavasa-dev');
		$this->pixie->config->set('db.default.service-account-name', '50021251974-0kli84jjumrfb9f38bf9mg0scgjh3b4m@developer.gserviceaccount.com');
		$this->pixie->config->set('db.default.private-key', file_get_contents('../../web/9dff04fbb97923cc383f49d5287c59d5a0449b3d-privatekey.p12'));
		$this->pixie->config->set('db.default.dataset-id', 'lavasa-dev');
		$this->AttractionDetailObj  = new \App\WebserviceAPI\AttractionDetail;
	}
	
	public function test_makeConnection()
	{
		self::$conn = $this->AttractionDetailObj->makeConnection($this->pixie);
		$this->assertNotNull(self::$conn);
	}
	/**
     * @depends test_makeConnection
     */
	public function test_getAttractionData()
	{
		self::$data = $this->AttractionDetailObj->getAttractionData(self::$conn,'6669549755695104');
		$this->assertNotEmpty(self::$data);
	}
	
	/**
     * @depends test_getAttractionData
	 * @dataProvider attractionDetailProvider
     */
    public function testActualVsExpected($expected)
    {
        $actual = json_encode(self::$data);
	    $this->assertEquals($expected, $actual);
    }

    public function attractionDetailProvider()
    {
		return array(
			array('{"ID":"6669549755695104","place_name":"Dimpys","lat":"18.396851","lng":"73.504719","type":"food","address":"Maharashtra, India","email":"dummy@dummy.com","featured_image":{"source":"fb","resourceID":"https:\/\/fbcdn-sphotos-b-a.akamaihd.net\/hphotos-ak-xap1\/t1.0-9\/10492245_723393611042220_9139938805002321673_n.jpg"},"view_street":1,"view_inside":"shcQTg4Y9qh9T0p5aspVvA","photo_gallery":[{"source":"gp","resourceID":"CoQBcQAAAK12TMVdA_lNX0QrVq1dKUYdoLmIfypTlCd6QkfX-fYJGfRP5pu5MdJoLgxQD_4Y5uhpux64r2PzfKwRwYQ6rL_ixc-8f9_YtwqKnIojKhlzfYHDefBbmwzrivIm6PmQ1gE7HEW03UrGDfUZEDijjj8egVwj_LjfsHVZq-_VYcz-EhCu_q5sLrzY7omBef54G4PxGhQywc9JeADjUPawOm2VCQ6QQ4_aLA"}],"amenities":["https:\/\/cdn3.iconfinder.com\/data\/icons\/bodybuilding\/500\/barbell_fitnessstrength_weight_exercise_expander_fitness_trainer_fitness_room_gym_gymnastic_health-256.png","http:\/\/icons.iconarchive.com\/icons\/jamespeng\/medical\/128\/medical-bed-icon.png","http:\/\/etc-mysitemyway.s3.amazonaws.com\/icons\/legacy-previews\/icons-256\/blue-jelly-icons-people-things\/061044-blue-jelly-icon-people-things-bed1-sc43.png"],"open_now":true,"opening_hours":{"weekday":{"open":"11:30","close":"18:30"},"weekend":{"open":"12:30","close":"17:30"}},"bookable":true,"price":2399,"reviews_count":4312,"checkin":"12:00","checkout":"10:00"}'));
		
    }

}
?>