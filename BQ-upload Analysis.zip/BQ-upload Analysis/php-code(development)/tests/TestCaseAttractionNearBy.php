<?php
class TestCaseAttractionNearBy extends PHPUnit_Framework_TestCase
{
	private $dbconn,$AttractionNearByObj;
	public static $connPDO,$connDatastore,$data,$arrIDs;
	protected function setUp(){
		//$this->dbconn = new PDO('mysql:host=localhost;dbname=geodata','root','');
		//$this->dbconn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$pixie = $this->pixie = new \PHPixie\Pixie();
		$this->pixie-> app_namespace = 'App\\';
		$pixie->db = new \PHPixie\DB($pixie);
		$pixie->orm = new \PHPixie\ORM($pixie);
        
		$this->pixie->config->set('db.PDO.connection', 'mysql:host=localhost;dbname=geodata');
		$this->pixie->config->set('db.PDO.user', 'root');
		$this->pixie->config->set('db.PDO.password', '');
		$this->pixie->config->set('db.PDO.driver', 'PDO');
		
		$this->pixie->config->set('db.default.driver', 'datastore');
		$this->pixie->config->set('db.default.application-id', 'lavasa-dev');
		$this->pixie->config->set('db.default.service-account-name', '50021251974-0kli84jjumrfb9f38bf9mg0scgjh3b4m@developer.gserviceaccount.com');
		$this->pixie->config->set('db.default.private-key', file_get_contents('../../web/9dff04fbb97923cc383f49d5287c59d5a0449b3d-privatekey.p12'));
		$this->pixie->config->set('db.default.dataset-id', 'lavasa-dev');
		$this->AttractionNearByObj  = new \App\WebserviceAPI\AttractionNearBy;
	}
	
	public function test_makeConnection()
	{
		self::$connPDO = $this->AttractionNearByObj->makeConnection($this->pixie,'PDO');
		$this->assertNotNull(self::$connPDO);
		self::$connDatastore = $this->AttractionNearByObj->makeConnection($this->pixie,'datastore');
		$this->assertNotNull(self::$connDatastore);
	}
	/**
     * @depends test_makeConnection
     */
	public function test_getPlaceIds()
	{
		self::$arrIDs = $this->AttractionNearByObj->getPlaceIds($this->pixie,self::$connPDO,'18.40249110','73.504929299999960','500','food','0','10');
		$this->assertNotNull(self::$arrIDs);
	}
	/**
     * @depends test_makeConnection
     */
    public function test_getAttractionsNearBy()
    {
        self::$data = $this->AttractionNearByObj->getAttractionsNearBy(self::$connDatastore,'5164439938531328');
		$this->assertNotEmpty(self::$data);
    }
	
	/**
     * @depends test_getAttractionsNearBy
	 * @dataProvider attractionNearByProvider
     */
    public function testActualVsExpected($expected)
    {
        $actual = json_encode(self::$data);
	    $this->assertEquals($expected, $actual);
    }
	
    public function attractionNearByProvider()
    {
		return array(
			array('{"ID":"5164439938531328","place_name":"Cafe Coffee Day","lat":"18.406522","lng":"73.505752","type":"food","address":"Maharashtra, India","email":"dummy@dummy.com"}'));
		
    }
}
?>