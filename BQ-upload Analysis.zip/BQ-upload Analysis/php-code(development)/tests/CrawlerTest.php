<?php
class Crawler_Test extends PHPUnit_Framework_TestCase
{
	
	protected function setUp(){
/*
		$db = new PDO('mysql:host=10.0.0.96;dbname=testIDG','minyanville','79m8Bc72A4');
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$db->exec("INSERT INTO constants(first_name,last_name,email_id) VALUES ('Avani','Mehta','avani.mehta@mediaagility.com')");
		$db->exec("INSERT INTO constants(first_name,last_name,email_id) VALUES ('Ashish','Kharolia','ashish.kharolia@mediaagility.com')");
		$db->exec("INSERT INTO email_exclusions(email_id) VALUES ('avani.mehta@mediaagility.com')");*/
		$pixie = $this->pixie = new \PHPixie\Pixie();
		$this->pixie-> app_namespace = 'App\\';
		$pixie->db = new \PHPixie\DB($pixie);
		$pixie->orm = new \PHPixie\ORM($pixie);
/*	        $this->pixie->config->set('db.default.connection', 'mysql:host=10.0.0.96;dbname=testIDG');
		$this->pixie->config->set('db.default.driver', 'pdo');
		$this->pixie->config->set('db.default.user', 'minyanville');
		$this->pixie->config->set('db.default.password', '79m8Bc72A4');*/
		
	}
	public function testAPICaller()
	{
		$CrawlerObj  = new \App\Controller\Crawler($this->pixie);
		$testApiUrl = 'https://graph.facebook.com/v2.1/PhilzCoffeeCastro?access_token=594236164024206|7b464d1da6f24ef1512b52a2fd77087c';
		$response = $CrawlerObj->api_caller($testApiUrl);
		$this->assertObjectHasAttribute('id',$response);
	}

	public function testFetchNearby()
	{
		$CrawlerObj  = new \App\Controller\Crawler($this->pixie);
		$response = $CrawlerObj->parsenearby_data('food');
		$this->assertArrayHasKey('places',$response);
	}

	public function testFetchPlaceDetails()
	{
		$CrawlerObj  = new \App\Controller\Crawler($this->pixie);
		$response = $CrawlerObj->parseplacedetail_data('ChIJP1ndqqyfwjsR6tJtIdJ2cHI');
		$this->assertArrayHasKey('name',$response);
	}
	
}
