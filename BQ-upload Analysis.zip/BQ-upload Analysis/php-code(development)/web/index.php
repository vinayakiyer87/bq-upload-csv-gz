<?php
ob_start();
//session_start();
/*require_once 'Datastore/config.php';
require_once 'Datastore/DatastoreService.php';
require_once 'Datastore/UserModel.php';
require_once 'Datastore/RoleModel.php';
require_once 'Datastore/UserLoginModel.php';

$google_api_config = [
'application-id' => 'lavasa-dev',
'service-account-name' => '50021251974-0kli84jjumrfb9f38bf9mg0scgjh3b4m@developer.gserviceaccount.com',
'private-key' => file_get_contents('9dff04fbb97923cc383f49d5287c59d5a0449b3d-privatekey.p12'),
'dataset-id' => 'lavasa-dev'
];
*/

$root = dirname(__DIR__);
$loader = require $root.'/vendor/autoload.php';
$loader->add('', $root.'/classes/');

$loader->add('PHPixie', $root.'/vendor/phpixie/core/classes/');
$loader->add('PHPixie', $root.'/vendor/phpixie/db/classes/');
$loader->add('PHPixie',$root.'/vendor/phpixie/orm/classes/');


//DatastoreService::setInstance(new DatastoreService($google_api_config));
$pixie = new \App\Pixie;
$pixie->bootstrap($root)->handle_http_request();