<?php
require_once 'google-api-php-client-1.1.2/src/Google/Client.php';
require_once 'google-api-php-client-1.1.2/src/Google/Service/Bigquery.php';

session_start();

$client = new Google_Client();
// Visit https://developers.google.com/console to generate your
// oauth2_client_id, oauth2_client_secret, and to register your oauth2_redirect_uri.

//$client->setClientId('373387281435-9mns33f6nfa4t3o6kbkeutqc8k5dpaa8.apps.googleusercontent.com');
//$client->setClientId('373387281435-bgj27olmfrddnsgqeoq377moi1ns23kt.apps.googleusercontent.com');

//$client->setClientSecret('Za9cO-lQoBgDbQuHycfZtxUr');
$client->setRedirectUri('http://axis-bank.appspot.com/index.php');
//$service_token_file_location = 'keys/bigquery_current_service_token.json';
// Your project id
$project_id = 'axis-bank';
$client->setApplicationName("axis-bank");

$key = file_get_contents('keys/axis-bank-ee77ece0c270.p12');

$client->setAssertionCredentials(new Google_Auth_AssertionCredentials(
                "373387281435-bgj27olmfrddnsgqeoq377moi1ns23kt.apps.googleusercontent.com",
                array('https://www.googleapis.com/auth/bigquery'),
                $key));
	
// Instantiate a new BigQuery Client 
$bigqueryService = new Google_Service_Bigquery($client);		

if (isset($_REQUEST['logout'])) {
  unset($_SESSION['access_token']);
}

if (isset($_SESSION['access_token'])) {
  $client->setAccessToken($_SESSION['access_token']);
} else {
  $client->setAccessToken($client->authenticate());
  $_SESSION['access_token'] = $client->getAccessToken();
}

if (isset($_GET['code'])) {

  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
}
?>
<!doctype html>
<html>
<head>
  <title>BigQuery API Sample</title>
</head>
<body>
<div id='container'>
  <div id='top'><h1></h1></div>
  <div id='main'>
<?php

  $query = new Google_Service_Bigquery_QueryRequest();
  echo "check";
	//$query->setQuery('SELECT TOP( title, 10) as title, COUNT(*) as revision_count FROM [publicdata:samples.wikipedia] WHERE wp_namespace = 0;');
	$query->setQuery('SELECT * FROM [mydataset.mytab]');
	//print_r($query);	
  
 // $jobs = $bigqueryService->jobs;
  
//	print_r($jobs);
  //$response = $jobs->query($project_id, $query);
	$result = exec_query($query);
	print_r($result);
  // Do something with the BigQuery API $response data
  //print_r($response);
  
  function exec_query($query){
	global $bigqueryService, $project_id;
	try{
		$jobs = $bigqueryService->jobs;
		$response = $jobs->query($project_id, $query);
		$schema = $response->getSchema();
		$fields = $schema->getFields();
		$rows = $response->getRows();
		
		$count = $response->totalRows;
		if($count>0){
			$arrField = array();
			foreach ($fields as $field=>$name){
				$arrField[$field]=$name['name'];
			}
			$result = array();
			foreach ($rows as $row=>$val){
				foreach ($val['modelData']['f'] as $k=>$v){
					$result[$row][$arrField[$k]]=$v['v'];
				}
			}
			if(!empty($result)){
				return $result;
			}
		}
	}catch (Exception $e){
   		echo $e->getMessage();
	}
}

?>
  </div>
</div>
</body>
</html>