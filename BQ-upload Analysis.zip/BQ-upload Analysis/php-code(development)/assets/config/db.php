<?php
return array(
	'default' => array(
		'application-id' => 'clean-india-dev',
		'driver' => 'Datastore',
		'service-account-name' => '624351111132-e7rs2ghulia0m6e4on2cg0f8hhkuo42c@developer.gserviceaccount.com',
		'private-key' => file_get_contents('cleanindia-acd44e7aaedd.p12'),
		'dataset-id' => 'clean-india-dev'
	),
	/*
	'PDO' => array(
		'user' => 'ashish',
		'password' => 'Zd(F8hL0Xos6NNB',
		'driver' => 'PDO',
		'connection' => 'mysql:host=173.194.241.214;dbname=lavasa_dev;unix_socket=/cloudsql/mediaagility.com:media-agility:ma-web',
	),
	
	/*/
		/*
	'PDO' => array(
		'user' => 'root',
		'password' => '',
		'driver' => 'PDO',
		'connection' => 'mysql:host=localhost;dbname=lavasa_dev;unix_socket=/cloudsql/mediaagility.com:media-agility:ma-web',
	),
	'PDO' => array(
		'user' => 'minyanville',
		'password' => '79m8Bc72A4',
		'driver' => 'PDO',
		'connection' => 'mysql:host=10.0.0.96;dbname=cleanindia;unix_socket=/cloudsql/mediaagility.com:media-agility:ma-web',

	),
	
	'PDO' => array(
		'user' => 'cleanindia',
		'password' => '9o3L33(S@OB15tj',
		'driver' => 'PDO',
		//173.194.253.94
		//'Connection' is required if you use the PDO driver
		'connection' => 'mysql:host=173.194.241.214;dbname=cleanindia;unix_socket=/cloudsql/mediaagility.com:media-agility:ma-web',	
	),
	*/
	'PDO' => array(
		'user' => 'root',
		'password' => '',
		'driver' => 'PDO',
		//173.194.253.94
		//'Connection' is required if you use the PDO driver
		'connection' => 'mysql:host=localhost;dbname=cleanindia;unix_socket=/cloudsql/mediaagility.com:media-agility:ma-web',	
	),
	
	/*
	'PDO' => array(
		'user' => 'root',
		'password' => '',
		'driver' => 'PDO',
		//173.194.253.94
		//'Connection' is required if you use the PDO driver
		'connection' => 'mysql:host=localhost;dbname=cleanindia;',	
	)*/

);
