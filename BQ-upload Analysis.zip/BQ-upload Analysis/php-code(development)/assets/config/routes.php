<?php

return array(
	'default' => array(
		'(/<controller>(/<action>(/<id>)(/<token>)))', 
		array(
			'controller' => 'Login',
			'action' => 'index'
		),
	),
	'route1' => array('/url',  array(
                'controller' => 'Webservice',
                'action' => 'index'
            ), array('POST') 
    ),
);
