<h2><?php echo "Hello $first_name $last_name";?></h2>
<h2><?php echo "Email : ".$email;?></h2>
<h2><?php 
if(isset($message)) 
{ 
	echo $message; 
} ?>
</h2>
<a href = "/Logout"><button>Logout</button></a>
