<!doctype html>
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Web Application</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic" rel="stylesheet" type="text/css">
        <!-- needs images, font... therefore can not be part of ui.css -->
        <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="bower_components/weather-icons/css/weather-icons.min.css">
        <!-- end needs images -->

            <link rel="stylesheet" href="styles/main.css">

    </head>
    <body data-ng-app="app" id="app" data-custom-background="" data-off-canvas-nav="">
        <!--[if lt IE 9]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

		 <div class="signin-body">
		        <div class="container">
		            <div class="form-container">
		                <section class="row signin-social text-center">
		                    <div class="space"></div>
		                    <a href="/Facebook" class="btn-icon btn-icon-sm bg-facebook"><i class="fa fa-facebook"></i>Facebook</a>
		                    <div class="space"></div>
		                    <a href="javascript:;" class="btn-icon btn-icon-sm bg-google-plus"><i class="fa fa-google-plus"></i>Google</a>
		                </section>
		            </div>
		        </div>
		    </div>

        <script src="http://maps.google.com/maps/api/js?sensor=false"></script>
        <script src="scripts/vendor.js"></script>

        <script src="scripts/ui.js"></script>

        <script src="scripts/app.js"></script>
    </body>
</html>
