<!DOCTYPE html>
<html>
	<head>
		<title>PHPixie</title>
	</head>
	<body>
		<!-- Here is where we include a subtemplate -->
		<?php echo "a";?>
	</body>
</html>
