#!/usr/bin/bash
#DATEVAL=`date '+%d%b%y'`
#DATEVAL=$(date --date="yesterday" +"%d%b%y")
FILEDIR='/data2/source-data/archived/'
cd $FILEDIR
export ORACLE_HOME='/oracle/ora11g/11gbase/dbhome'

export PATH=$PATH:$ORACLE_HOME/bin
#export PATH=$PATH:/home/axbigq/google-cloud-sdk/bin/gsutil
#export BOTO_CONFIG="/home/axbigq/.config/gcloud/legacy_credentials/abhishek.srivastava\@mediaagility.com/.boto"
export BOTO_CONFIG="/home/axbigq/.boto"
export ORACLE_SID='axbigq'

array=(2015-03-01 2015-03-02 2015-03-03 2015-03-04 2015-03-05 2015-03-06 2015-03-07 2015-03-08 2015-03-09 2015-03-10 2015-03-11 2015-03-12 2015-03-13 2015-03-14 2015-03-15 2015-03-16 2015-03-17 2015-03-18 2015-03-19 2015-03-20 2015-03-21 2015-03-22 2015-03-23 2015-03-24 2015-03-25 2015-03-26 2015-03-27 2015-03-28 2015-03-29 2015-03-30 2015-03-31)


for i in "${array[@]}"
do
DATEVAL=$i
#QRYDATE=$(date --date="yesterday" +"%Y-%m-%d")
QRYDATE=$i
FILE=$DATEVAL'.csv'
DATASET='mydataset.temp_data'
FILEGZ=$DATEVAL'.csv.gz'
DATEVALLOG=$DATEVAL'.log'
BUCKET="gs://axis-prod-data"


if test -s "$FILEGZ"
then        
        rm $FILEGZ
fi

if test -s "$FILE"
then
    rm $FILE
fi

sqlplus -s big_query/axis#1234@axbigq  <<EOF
SET PAGESIZE 0
SET COLSEP |
SET LINESIZE 32767
SET FEEDBACK OFF
SET HEADING OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET TERMOUT OFF
SET TRIMOUT ON
SET WRAP ON

SPOOL $FILE

SELECT
ACID,
TO_CHAR(TRAN_DATE,'YYYY-MM-DD HH:MM:SS')  as TRAN_DATE,
TRIM(TRAN_ID),
TRIM(PART_TRAN_SRL_NUM),
TRIM(TRAN_SUB_TYPE),
TRIM(PART_TRAN_TYPE),
'"' || REPLACE(TRIM(TRAN_PARTICULAR),'"','""') || '"'  as txn_particulars,
'"' || REPLACE(TRIM(TRAN_RMKS),'"','""') || '"'  as txn_remarks,
TRIM(INSTRMNT_NUM) as INSTR,
'"' || REPLACE(TRIM(TRAN_RMKS_2),'"','""') || '"' as TXN_REMARKS_2,
TRIM(RCRE_USER_ID) as RCRE_USER_ID,
TRIM(TRAN_TYPE) as tran_type,
TRIM(TRAN_AMT) as TRAN_AMOUNT,
TRIM(SOL_ID_INIT) as SOL_ID_INIT,
TRIM(SOL_ID_ACC) as Sol_Id_Acc
from ODS_TRAN_DATA_JAN_MAR_15 WHERE TRAN_DATE=TO_DATE('$QRYDATE','YYYY-MM-DD');

EXIT
EOF

gzip $FILE
FILESIZE=stat -c %s $FILEZ

if $FILESIZE>0 
then 
sqlplus -s big_query/axis#1234@axbigq <<-EOF
     whenever oserror exit failure
     whenever sqlerror exit failure
     INSERT INTO PROCESS_STATUS
     SELECT MAX(PROCESS_ID)+1,'($DATEVAL) EXTRACTION AND COMPRESSION',CURRENT_TIMESTAMP,'1' FROM PROCESS_STATUS;


     exit
EOF

/home/axbigq/google-cloud-sdk/bin/gsutil -m cp -L $DATEVALLOG $FILEGZ $BUCKET

#if [ "$status" -ne 0 ];
#then
#       DATE_LOG=`date '+%Y-%m-%d %H:%M:%S'`
#       echo $DATE_LOG' SEVERE: error in downloading file'
#fi
#bq load -F| $DATASET $FILEGZ bqschema.json
if /home/axbigq/google-cloud-sdk/bin/gsutil ls -l $BUCKET/$FILEGZ ; then
        echo "uploaded";
else
        /home/axbigq/google-cloud-sdk/bin/gsutil -m cp -L $DATEVALLOG $FILEGZ $BUCKET
        echo "uploaded again";
fi
sqlplus -s big_query/axis#1234@axbigq <<-EOF    
 whenever oserror exit failure     
 whenever sqlerror exit failure     
 INSERT INTO PROCESS_STATUS     
 SELECT MAX(PROCESS_ID)+1,'($DATEVAL) DATA UPLOADED',CURRENT_TIMESTAMP,'1' FROM PROCESS_STATUS;     
 exit
EOF


else

sqlplus -s big_query/axis#1234@axbigq <<-EOF    
 whenever oserror exit failure     
 whenever sqlerror exit failure     
 INSERT INTO PROCESS_STATUS     
 SELECT MAX(PROCESS_ID)+1,'($DATEVAL) EXTRACTION AND COMPRESSION',CURRENT_TIMESTAMP,'0' FROM PROCESS_STATUS;     
 exit
EOF
fi
#set pagesize 0 feedback off verify off heading off echo off;
done
