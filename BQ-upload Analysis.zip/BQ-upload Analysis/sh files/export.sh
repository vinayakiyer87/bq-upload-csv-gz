#!/usr/bin/bash
#DATEVAL=`date '+%Y-%m-%d'`
#DATEVAL=$(date --date="yesterday" +"%d%b%y")
DATEVAL=$(date --date="yesterday" +"%Y-%m-%d")
#DATEVAL='2016-12-06'
FILEDIR='/data2/source-data/archived/'
export ORACLE_HOME='/oracle/ora11g/11gbase/dbhome'
export PATH=$PATH:$ORACLE_HOME/bin
#export PATH=$PATH:/home/axbigq/google-cloud-sdk/bin/gsutil
#export BOTO_CONFIG="/home/axbigq/.config/gcloud/legacy_credentials/abhishek.srivastava\@mediaagility.com/.boto"
export BOTO_CONFIG="/home/axbigq/.boto"
export ORACLE_SID='axbigq'


VARSTATUS=$(sqlplus -s big_query/axis#1234@axbigq <<EOF
        set pagesize 0 feedback off verify off heading off echo off;    
     whenever oserror exit failure
     whenever sqlerror exit failure
     SELECT STATUS FROM AUDIT_TABLE WHERE DAY_ID='$DATEVAL';        
 exit;
EOF
)


if test $VARSTATUS = 1
then
VARTABLE=$(sqlplus -s big_query/axis#1234@axbigq <<EOF
        set pagesize 0 feedback off verify off heading off echo off;    
     	whenever oserror exit failure  
   	whenever sqlerror exit failure    
	SELECT TABLE_NAME FROM AUDIT_TABLE WHERE DAY_ID='$DATEVAL';        
 exit;
EOF
)

#DATEVAL='2015-04-06'
#QRYDATE=$(date --date="yesterday" +"%Y-%m-%d")
#QRYDATE='2015-06-18'
FILE=$DATEVAL'.csv'
#DATASET='mydataset.temp_data'
FILEGZ=$DATEVAL'.csv.gz'
DATEVALLOG=$DATEVAL'.log'
BUCKET="gs://axis-prod-data"

cd $FILEDIR

if test -s "$FILEGZ"
then        
	rm $FILEGZ
fi

if test -s "$FILE"
then
    rm $FILE
fi

if test -s "$DATEVALLOG"
then
    rm $DATEVALLOG
fi

sqlplus -s big_query/axis#1234@axbigq  <<EOF
SET PAGESIZE 0
SET COLSEP |
SET LINESIZE 32767
SET FEEDBACK OFF
SET HEADING OFF
SET TRIMSPOOL ON
SET ECHO OFF
SET TERMOUT OFF
SET TRIMOUT ON
SET WRAP ON

SPOOL $FILE

SELECT
ACID,
TO_CHAR(TRAN_DATE,'YYYY-MM-DD HH:MM:SS')  as TRAN_DATE,
TRIM(TRAN_ID),
TRIM(PART_TRAN_SRL_NUM),
TRIM(TRAN_SUB_TYPE),
TRIM(PART_TRAN_TYPE),
'"' || REPLACE(TRIM(TRAN_PARTICULAR),'"','""') || '"'  as txn_particulars,
'"' || REPLACE(TRIM(TRAN_RMKS),'"','""') || '"'  as txn_remarks,
TRIM(INSTRMNT_NUM) as INSTR,
'"' || REPLACE(TRIM(TRAN_RMKS_2),'"','""') || '"' as TXN_REMARKS_2,
TRIM(RCRE_USER_ID) as RCRE_USER_ID,
TRIM(TRAN_TYPE) as tran_type,
TRIM(TRAN_AMT) as TRAN_AMOUNT,
TRIM(SOL_ID_INIT) as SOL_ID_INIT,
TRIM(SOL_ID_ACC) as Sol_Id_Acc
from $VARTABLE WHERE TRAN_DATE=TO_DATE('$DATEVAL','YYYY-MM-DD') ; 


EXIT
EOF

gzip $FILE
#FILESIZE=stat -c %s $FILEZ

#if $FILESIZE>0 
if test -s $FILEZ
then
sqlplus -s big_query/axis#1234@axbigq <<-EOF
     whenever oserror exit failure
     whenever sqlerror exit failure
     INSERT INTO PROCESS_STATUS
     SELECT MAX(PROCESS_ID)+1,'($DATEVAL) EXTRACTION AND COMPRESSION',CURRENT_TIMESTAMP,'1' FROM PROCESS_STATUS;


     exit
EOF


/home/axbigq/google-cloud-sdk/bin/gsutil -m cp -L $DATEVALLOG $FILEGZ $BUCKET

#if [ "$status" -ne 0 ];
#then
#       DATE_LOG=`date '+%Y-%m-%d %H:%M:%S'`
#       echo $DATE_LOG' SEVERE: error in downloading file'
#fi
#bq load -F| $DATASET $FILEGZ bqschema.json
if /home/axbigq/google-cloud-sdk/bin/gsutil ls -l $BUCKET/$FILEGZ ; then
        echo "uploaded";
else
	/home/axbigq/google-cloud-sdk/bin/gsutil -m cp -L $DATEVALLOG $FILEGZ $BUCKET
        echo "uploaded again";
fi
sqlplus -s big_query/axis#1234@axbigq <<-EOF    
 whenever oserror exit failure     
 whenever sqlerror exit failure     
 INSERT INTO PROCESS_STATUS     
 SELECT MAX(PROCESS_ID)+1,'($DATEVAL) DATA UPLOADED',CURRENT_TIMESTAMP,'1' FROM PROCESS_STATUS;     
 exit
EOF

fi
else

sqlplus -s big_query/axis#1234@axbigq <<-EOF    
 whenever oserror exit failure     
 whenever sqlerror exit failure     
 INSERT INTO PROCESS_STATUS     
 SELECT MAX(PROCESS_ID)+1,'($DATEVAL) EXTRACTION AND COMPRESSION',CURRENT_TIMESTAMP,'0' FROM PROCESS_STATUS;     
 exit
EOF

#set pagesize 0 feedback off verify off heading off echo off;

fi
