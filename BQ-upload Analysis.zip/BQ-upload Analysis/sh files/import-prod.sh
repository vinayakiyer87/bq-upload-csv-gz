#!/usr/bin/bash
export ORACLE_HOME='/oracle/ora11g/11gbase/dbhome'
export PATH=$PATH:$ORACLE_HOME/bin
export BOTO_CONFIG="/home/axbigq/.boto"
export ORACLE_SID='axbigq'

FILEDIR='/data2/source-data/archived/imported'
cd $FILEDIR

BUCKET="gs://axis-prod-export"
FOLDER=`date '+%h_%Y'`


LOCALFOLD=`date '+%b_%Y' --date '1 month ago'`
LOCALFOLD="$(echo ${LOCALFOLD} | tr 'a-z' 'A-Z')"
mkdir $LOCALFOLD 
#FOLDER='JAN_2015'
#MON=`date '+%m'`
#FOLD=$FOLDER | tr [:lower:] [:upper:]
FOLD="$(echo ${FOLDER} | tr 'a-z' 'A-Z')"

#LOCALFOLD='JUL_2015'
#FILEPATH="$FILEDIR/$FOLD"
FILEPATH="$FILEDIR/$LOCALFOLD"

array=(ROLLUP_Cash_Oth ROLLUP_Cash_Own ROLLUP_Chq_Clg ROLLUP_Chq_OSC ROLLUP_Chq_Trf)
#array=(ROLLUP_Cash_Own)
VARSTATUS=0;
for i in "${array[@]}"
do
#echo $FOLD
#ROLLUP_Cash_Oth-000000000000.csv.gz
#/home/axbigq/google-cloud-sdk/bin/gsutil


#VARSTATUS=$(sqlplus -s big_query/axis#1234@axbigq <<EOF
#        set pagesize 0 feedback off verify off heading off echo off;    
#     whenever oserror exit failure
#     whenever sqlerror exit failure
#  SELECT PROCESS_STATUS FROM PROCESS_STATUS WHERE INSTR(PROCESS_NAME,'$i-$FOLD')>0 AND PROCESS_STATUS='1' GROUP by PROCESS_STATUS,PROCESS_NAME;   
#exit;
#EOF
#)
#echo $VARSTATUS;

#if test $VARSTATUS -ne 1
#then
    

if /home/axbigq/google-cloud-sdk/bin/gsutil ls -l "$BUCKET/$FOLD/$i*" ; then

	if test -s "$FILEPATH/$i-cp.log"
        then
		 rm $FILEPATH/$i-cp.log             
        fi

	/home/axbigq/google-cloud-sdk/bin/gsutil cp -c -L "$FILEPATH/$i-cp.log" "$BUCKET/$FOLD/$i*" "$FILEPATH"
	if test -s "$FILEPATH/$i-000000000000.csv.gz"
	then 
		gunzip $FILEPATH/$i*.csv.gz
		if test -s "$FILEPATH/$i-000000000000.csv"
                then
			sed -i 1d $FILEPATH/$i*
			cd $FILEPATH
			SOURCE_FILE="$i*.csv"
			BIG_FILE=$i-file.csv
			cat $SOURCE_FILE > $BIG_FILE
			cd ..

			if test -s "$FILEDIR/$i-$LOCALFOLD.log"
			then        
			        rm $FILEDIR/$i-$LOCALFOLD.log
			fi
	#		rm $FILEDIR/$i-$FOLD.log
			sqlldr big_query/axis#1234@axbigq  control="$FILEDIR/$i.ctl" log="$FILEDIR/$i-$LOCALFOLD.log" data="$FILEPATH/$i-file.csv" > /dev/null 2>&1

		        sqlplus -s big_query/axis#1234@axbigq <<-EOF    
			whenever oserror exit failure     
			whenever sqlerror exit failure      
			INSERT INTO PROCESS_STATUS    
			SELECT MAX(PROCESS_ID)+1,'$i-$LOCALFOLD DATA LOADED SUCCESSFULLY',CURRENT_TIMESTAMP,'1' FROM PROCESS_STATUS;     
			exit
			EOF
		fi
	fi
else
	sqlplus -s big_query/axis#1234@axbigq <<-EOF    
	whenever oserror exit failure     
	whenever sqlerror exit failure     
	INSERT INTO PROCESS_STATUS     
	SELECT MAX(PROCESS_ID)+1,'$i-$LOCALFOLD NOT FOUND ON CLOUD STORAGE',CURRENT_TIMESTAMP,'0' FROM PROCESS_STATUS;     
	exit
	EOF

fi
#fi


done



